/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  UserRole,
  AssessmentRecord,
  Violation,
  ArchitecturalRequest,
  WorkOrder,
  Announcement,
  Resident,
  BoardMeeting,
  BoardResolution,
  GoverningDocument,
} from './types';
import { StorageService } from './services/storage';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardOverview } from './components/DashboardOverview';
import { DuesLedger } from './components/DuesLedger';
import { ViolationsManager } from './components/ViolationsManager';
import { MaintenanceDispatch } from './components/MaintenanceDispatch';
import { CommunicationsHub } from './components/CommunicationsHub';
import { BoardPortal } from './components/BoardPortal';
import { DocumentVault } from './components/DocumentVault';
import { ResidentPortal } from './components/ResidentPortal';
import {
  PaymentModal,
  NewViolationModal,
  NewWorkOrderModal,
  BroadcastModal,
  NewArcModal,
  DocumentPreviewModal,
} from './components/Modals';
import { CheckCircle2, Info, X } from 'lucide-react';

interface Toast {
  id: string;
  type: 'success' | 'info';
  message: string;
}

export default function App() {
  // Global App State
  const [activeRole, setActiveRole] = useState<UserRole>('property_manager');
  const [currentTab, setCurrentTab] = useState<string>('overview');

  // Loaded Entities from Persistent Storage
  const [assessments, setAssessments] = useState<AssessmentRecord[]>(StorageService.getAssessments);
  const [violations, setViolations] = useState<Violation[]>(StorageService.getViolations);
  const [arcRequests, setArcRequests] = useState<ArchitecturalRequest[]>(StorageService.getArcRequests);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(StorageService.getWorkOrders);
  const [announcements, setAnnouncements] = useState<Announcement[]>(StorageService.getAnnouncements);
  const [residents, setResidents] = useState<Resident[]>(StorageService.getResidents);
  const [meetings, setMeetings] = useState<BoardMeeting[]>(StorageService.getMeetings);
  const [resolutions, setResolutions] = useState<BoardResolution[]>(StorageService.getResolutions);
  const [documents, setDocuments] = useState<GoverningDocument[]>(StorageService.getDocuments);

  // Modals state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedAssessmentForPay, setSelectedAssessmentForPay] = useState<AssessmentRecord | null>(null);
  const [isViolationModalOpen, setIsViolationModalOpen] = useState(false);
  const [isWorkOrderModalOpen, setIsWorkOrderModalOpen] = useState(false);
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [isArcModalOpen, setIsArcModalOpen] = useState(false);
  const [previewDocument, setPreviewDocument] = useState<GoverningDocument | null>(null);

  // Toast notification state
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (message: string, type: 'success' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Sync assessments
  const handleRecordPayment = (paymentData: {
    recordId: string;
    amount: number;
    method: string;
    reference: string;
  }) => {
    const updated = assessments.map((a) => {
      if (a.id === paymentData.recordId) {
        const newBalance = Math.max(0, a.balance - paymentData.amount);
        return {
          ...a,
          balance: newBalance,
          status: (newBalance === 0 ? 'Paid' : 'Pending') as AssessmentRecord['status'],
          lastPaymentDate: new Date().toISOString().slice(0, 10),
          paymentMethod: `${paymentData.method} (${paymentData.reference})`,
        };
      }
      return a;
    });
    setAssessments(updated);
    StorageService.saveAssessments(updated);
    addToast(
      `Payment of $${paymentData.amount.toFixed(2)} recorded successfully via ${paymentData.method}.`
    );
  };

  const handleApplyLateFee = (recordId: string, feeAmount: number) => {
    const updated = assessments.map((a) => {
      if (a.id === recordId) {
        return {
          ...a,
          balance: a.balance + feeAmount,
          status: 'Overdue' as AssessmentRecord['status'],
          notes: `${a.notes ? a.notes + ' · ' : ''}Late assessment penalty of $${feeAmount} added on ${new Date().toISOString().slice(0, 10)}.`,
        };
      }
      return a;
    });
    setAssessments(updated);
    StorageService.saveAssessments(updated);
    addToast(`Late fee of $${feeAmount.toFixed(2)} applied to account ledger.`, 'info');
  };

  const handleToggleAutoPay = (recordId: string) => {
    const updated = assessments.map((a) => {
      if (a.id === recordId) {
        const nextState = !a.autoPay;
        return {
          ...a,
          autoPay: nextState,
          paymentMethod: nextState ? 'ACH Autopay Active' : undefined,
        };
      }
      return a;
    });
    setAssessments(updated);
    StorageService.saveAssessments(updated);
    const rec = updated.find((a) => a.id === recordId);
    addToast(`Auto-pay for ${rec?.unit} is now ${rec?.autoPay ? 'enabled' : 'disabled'}.`);
  };

  const handleSendNotice = (record: AssessmentRecord) => {
    addToast(`Delinquency notice dispatched to ${record.email} via electronic delivery.`);
  };

  // Violations
  const handleUpdateViolationStage = (
    id: string,
    newStage: Violation['stage'],
    fineAdjustment = 0
  ) => {
    const updated = violations.map((v) => {
      if (v.id === id) {
        return {
          ...v,
          stage: newStage,
          fineAmount: v.fineAmount + fineAdjustment,
        };
      }
      return v;
    });
    setViolations(updated);
    StorageService.saveViolations(updated);
    addToast(`Violation escalated to: ${newStage}`);
  };

  const handleResolveViolation = (id: string) => {
    const updated = violations.map((v) => {
      if (v.id === id) {
        return {
          ...v,
          stage: 'Resolved' as Violation['stage'],
          resolvedDate: new Date().toISOString().slice(0, 10),
        };
      }
      return v;
    });
    setViolations(updated);
    StorageService.saveViolations(updated);
    addToast('Violation marked as Cured and archived to property records.');
  };

  const handleCreateViolation = (newVio: Omit<Violation, 'id'>) => {
    const newRecord: Violation = {
      ...newVio,
      id: `VIO-2026-${String(Math.floor(100 + Math.random() * 900))}`,
    };
    const updated = [newRecord, ...violations];
    setViolations(updated);
    StorageService.saveViolations(updated);
    addToast(`New violation logged for ${newVio.unit}. Notice issued.`);
  };

  // ARC Requests
  const handleCreateArc = (newArc: Omit<ArchitecturalRequest, 'id'>) => {
    const newRecord: ArchitecturalRequest = {
      ...newArc,
      id: `ARC-2026-${String(Math.floor(100 + Math.random() * 900))}`,
    };
    const updated = [newRecord, ...arcRequests];
    setArcRequests(updated);
    StorageService.saveArcRequests(updated);
    addToast(`Architectural application submitted for review by ARC Committee.`);
  };

  const handleVoteArc = (requestId: string, vote: 'Approve' | 'Deny', comment?: string) => {
    const voterName =
      activeRole === 'board_member'
        ? 'Eleanor Vance (Board President)'
        : 'Sarah Jenkins (Property Mgr)';

    const updated = arcRequests.map((arc) => {
      if (arc.id === requestId) {
        const existingVotes = arc.boardVotes.filter((v) => v.memberName !== voterName);
        const newVotes = [...existingVotes, { memberName: voterName, vote, comment }];
        const approveCount = newVotes.filter((v) => v.vote === 'Approve').length;
        return {
          ...arc,
          boardVotes: newVotes,
          status: (approveCount >= 2 ? 'Approved' : 'Under Review') as ArchitecturalRequest['status'],
        };
      }
      return arc;
    });
    setArcRequests(updated);
    StorageService.saveArcRequests(updated);
    addToast(`ARC vote [${vote}] recorded for application.`);
  };

  // Work Orders
  const handleUpdateWorkOrderStatus = (
    id: string,
    newStatus: WorkOrder['status'],
    actualCost?: number
  ) => {
    const updated = workOrders.map((w) => {
      if (w.id === id) {
        return {
          ...w,
          status: newStatus,
          actualCost: actualCost !== undefined ? actualCost : w.actualCost,
        };
      }
      return w;
    });
    setWorkOrders(updated);
    StorageService.saveWorkOrders(updated);
    addToast(`Work order status updated to: ${newStatus}`);
  };

  const handleCreateWorkOrder = (newWo: Omit<WorkOrder, 'id'>) => {
    const newRecord: WorkOrder = {
      ...newWo,
      id: `WO-${String(Math.floor(8000 + Math.random() * 999))}`,
    };
    const updated = [newRecord, ...workOrders];
    setWorkOrders(updated);
    StorageService.saveWorkOrders(updated);
    addToast(`Maintenance work order dispatched to ${newWo.vendorName}.`);
  };

  // Announcements
  const handleBroadcastAlert = (newAnn: Omit<Announcement, 'id'>) => {
    const newRecord: Announcement = {
      ...newAnn,
      id: `ANN-${String(Math.floor(300 + Math.random() * 699))}`,
    };
    const updated = [newRecord, ...announcements];
    setAnnouncements(updated);
    StorageService.saveAnnouncements(updated);
    addToast(`Broadcast sent via ${newAnn.deliveryChannels.join(', ')} to 184 Lots.`);
  };

  const handleTogglePinAnnouncement = (id: string) => {
    const updated = announcements.map((a) => (a.id === id ? { ...a, pinned: !a.pinned } : a));
    setAnnouncements(updated);
    StorageService.saveAnnouncements(updated);
    addToast('Announcement pin status toggled.');
  };

  // Board Portal Resolutions
  const handleCastBoardVote = (resolutionId: string, vote: 'Aye' | 'Nay' | 'Abstain') => {
    const voterName =
      activeRole === 'board_member' ? 'Eleanor Vance' : 'Sarah Jenkins';
    const voterRole = activeRole === 'board_member' ? 'President' : 'Property Manager';

    const updated = resolutions.map((res) => {
      if (res.id === resolutionId) {
        const filteredVotes = res.votes.filter((v) => v.member !== voterName);
        const newVotes = [
          ...filteredVotes,
          {
            member: voterName,
            role: voterRole,
            vote,
            timestamp: new Date().toISOString().slice(0, 16).replace('T', ' '),
          },
        ];
        return { ...res, votes: newVotes };
      }
      return res;
    });
    setResolutions(updated);
    StorageService.saveResolutions(updated);
    addToast(`Board vote recorded: ${vote} on resolution.`);
  };

  // Elena Rostova's personal assessment (Lot 108)
  const homeownerAssessment =
    assessments.find((a) => a.id === 'ASM-103') || assessments[0];
  const homeownerViolations = violations.filter((v) => v.unit.includes('Lot 108'));
  const homeownerArcRequests = arcRequests.filter((a) => a.unit.includes('Lot 108'));

  const overdueCount = assessments.filter((a) => a.status === 'Overdue' || a.status === 'In Collections').length;
  const openViolationsCount = violations.filter((v) => v.stage !== 'Resolved').length;
  const activeWorkOrdersCount = workOrders.filter((w) => w.status !== 'Completed').length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Strict One-Row Top Bar Contract */}
      <Header
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        activeRole={activeRole}
        onRoleChange={(role) => {
          setActiveRole(role);
          addToast(
            `Role switched to: ${
              role === 'property_manager'
                ? 'Property Manager'
                : role === 'board_member'
                ? 'Board Member'
                : 'Homeowner'
            }`,
            'info'
          );
        }}
        onQuickAction={() => {
          if (currentTab === 'dues') setIsPaymentModalOpen(true);
          else if (currentTab === 'violations') setIsViolationModalOpen(true);
          else if (currentTab === 'maintenance') setIsWorkOrderModalOpen(true);
          else if (currentTab === 'communications') setIsBroadcastModalOpen(true);
          else setIsPaymentModalOpen(true);
        }}
      />

      <div className="flex-1 flex max-w-full">
        {/* Sidebar Navigation */}
        <Sidebar
          currentTab={currentTab}
          onTabChange={setCurrentTab}
          activeRole={activeRole}
          onResetData={StorageService.resetAllData}
          overdueCount={overdueCount}
          openViolationsCount={openViolationsCount}
          activeWorkOrdersCount={activeWorkOrdersCount}
        />

        {/* Main Content Viewport */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
          {/* If Homeowner role is active AND on 'overview', show Homeowner Portal */}
          {activeRole === 'homeowner' && currentTab === 'overview' ? (
            <ResidentPortal
              currentAssessment={homeownerAssessment}
              myViolations={homeownerViolations}
              myArcRequests={homeownerArcRequests}
              announcements={announcements}
              onPayDues={() => {
                setSelectedAssessmentForPay(homeownerAssessment);
                setIsPaymentModalOpen(true);
              }}
              onSubmitArc={() => setIsArcModalOpen(true)}
              onReportIssue={() => setIsWorkOrderModalOpen(true)}
              onToggleAutoPay={() => handleToggleAutoPay(homeownerAssessment.id)}
            />
          ) : (
            <>
              {currentTab === 'overview' && (
                <DashboardOverview
                  assessments={assessments}
                  violations={violations}
                  workOrders={workOrders}
                  announcements={announcements}
                  meetings={meetings}
                  activeRole={activeRole}
                  onNavigate={setCurrentTab}
                  onOpenPaymentModal={() => {
                    setSelectedAssessmentForPay(null);
                    setIsPaymentModalOpen(true);
                  }}
                  onOpenViolationModal={() => setIsViolationModalOpen(true)}
                  onOpenWorkOrderModal={() => setIsWorkOrderModalOpen(true)}
                  onOpenBroadcastModal={() => setIsBroadcastModalOpen(true)}
                />
              )}

              {currentTab === 'dues' && (
                <DuesLedger
                  assessments={assessments}
                  activeRole={activeRole}
                  onRecordPayment={(rec) => {
                    setSelectedAssessmentForPay(rec);
                    setIsPaymentModalOpen(true);
                  }}
                  onApplyLateFee={handleApplyLateFee}
                  onToggleAutoPay={handleToggleAutoPay}
                  onSendNotice={handleSendNotice}
                  onOpenNewAssessmentModal={() => {
                    setSelectedAssessmentForPay(null);
                    setIsPaymentModalOpen(true);
                  }}
                />
              )}

              {currentTab === 'violations' && (
                <ViolationsManager
                  violations={violations}
                  arcRequests={arcRequests}
                  activeRole={activeRole}
                  onUpdateViolationStage={handleUpdateViolationStage}
                  onResolveViolation={handleResolveViolation}
                  onOpenNewViolationModal={() => setIsViolationModalOpen(true)}
                  onOpenNewArcModal={() => setIsArcModalOpen(true)}
                  onVoteArc={handleVoteArc}
                />
              )}

              {currentTab === 'maintenance' && (
                <MaintenanceDispatch
                  workOrders={workOrders}
                  activeRole={activeRole}
                  onUpdateStatus={handleUpdateWorkOrderStatus}
                  onOpenNewWorkOrderModal={() => setIsWorkOrderModalOpen(true)}
                />
              )}

              {(currentTab === 'communications' || currentTab === 'directory') && (
                <CommunicationsHub
                  announcements={announcements}
                  residents={residents}
                  activeRole={activeRole}
                  onOpenBroadcastModal={() => setIsBroadcastModalOpen(true)}
                  onOpenNewResidentModal={() => {
                    addToast('Resident self-registration open via resident portal invitation link.', 'info');
                  }}
                  onTogglePinAnnouncement={handleTogglePinAnnouncement}
                />
              )}

              {currentTab === 'board' && (
                <BoardPortal
                  meetings={meetings}
                  resolutions={resolutions}
                  activeRole={activeRole}
                  onCastVote={handleCastBoardVote}
                  onOpenNewResolutionModal={() => {
                    const newRes: BoardResolution = {
                      id: `RES-2026-${String(Math.floor(10 + Math.random() * 89))}`,
                      resolutionNo: `RES-2026-0${String(resolutions.length + 1)}`,
                      title: 'Clubhouse Veranda Solar Fan & Trellis Installation',
                      description: 'Procurement and installation of 4 commercial exterior damp-rated solar fans for member event comfort.',
                      budgetImpact: 3200,
                      category: 'Budget & Reserves',
                      status: 'Voting Open',
                      votes: [],
                    };
                    const updated = [newRes, ...resolutions];
                    setResolutions(updated);
                    StorageService.saveResolutions(updated);
                    addToast(`New resolution tabled: ${newRes.resolutionNo}`);
                  }}
                  onOpenNewMeetingModal={() => {
                    addToast('Board meeting invitation generated and synchronized to calendar.', 'info');
                  }}
                />
              )}

              {currentTab === 'documents' && (
                <DocumentVault
                  documents={documents}
                  activeRole={activeRole}
                  onPreviewDocument={(doc) => setPreviewDocument(doc)}
                  onUploadDocument={() => {
                    addToast('Document upload ready. Certified digital signature required.', 'info');
                  }}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Floating Action Modals */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        record={selectedAssessmentForPay}
        onSubmit={handleRecordPayment}
        assessments={assessments}
      />

      <NewViolationModal
        isOpen={isViolationModalOpen}
        onClose={() => setIsViolationModalOpen(false)}
        onSubmit={handleCreateViolation}
      />

      <NewWorkOrderModal
        isOpen={isWorkOrderModalOpen}
        onClose={() => setIsWorkOrderModalOpen(false)}
        onSubmit={handleCreateWorkOrder}
      />

      <BroadcastModal
        isOpen={isBroadcastModalOpen}
        onClose={() => setIsBroadcastModalOpen(false)}
        onSubmit={handleBroadcastAlert}
      />

      <NewArcModal
        isOpen={isArcModalOpen}
        onClose={() => setIsArcModalOpen(false)}
        onSubmit={handleCreateArc}
      />

      <DocumentPreviewModal
        isOpen={!!previewDocument}
        onClose={() => setPreviewDocument(null)}
        document={previewDocument}
      />

      {/* Non-intrusive Toast Stack */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="pointer-events-auto flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs text-white shadow-lg border border-slate-800 transition-all animate-in fade-in slide-in-from-bottom-2"
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            ) : (
              <Info className="h-4 w-4 text-blue-400 shrink-0" />
            )}
            <span className="font-medium">{toast.message}</span>
            <button
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="ml-2 text-slate-400 hover:text-white"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
