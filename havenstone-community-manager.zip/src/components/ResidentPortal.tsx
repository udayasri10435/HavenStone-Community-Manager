import React from 'react';
import { AssessmentRecord, Violation, ArchitecturalRequest, Announcement } from '../types';
import {
  CreditCard,
  CheckCircle,
  AlertTriangle,
  PlusCircle,
  FileText,
  Clock,
  Send,
  Home,
  ShieldCheck,
  Calendar,
} from 'lucide-react';

interface ResidentPortalProps {
  currentAssessment: AssessmentRecord;
  myViolations: Violation[];
  myArcRequests: ArchitecturalRequest[];
  announcements: Announcement[];
  onPayDues: () => void;
  onSubmitArc: () => void;
  onReportIssue: () => void;
  onToggleAutoPay: () => void;
}

export const ResidentPortal: React.FC<ResidentPortalProps> = ({
  currentAssessment,
  myViolations,
  myArcRequests,
  announcements,
  onPayDues,
  onSubmitArc,
  onReportIssue,
  onToggleAutoPay,
}) => {
  return (
    <div className="space-y-6">
      {/* Resident Welcome Hero */}
      <div className="rounded-2xl border border-slate-200/90 bg-gradient-to-r from-slate-900 to-slate-800 p-6 text-white shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs uppercase font-semibold tracking-wider text-emerald-400">
              Resident Self-Service Portal
            </span>
            <h1 className="text-2xl font-bold">Welcome home, Elena</h1>
            <p className="text-xs text-slate-300">
              Lot 108 · 1232 HavenStone Way · Account in Good Standing
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onReportIssue}
              className="rounded-lg border border-slate-700 bg-slate-800/80 px-3.5 py-2 text-xs font-medium text-white hover:bg-slate-700 transition-colors"
            >
              Report Amenity Issue
            </button>
            <button
              onClick={onSubmitArc}
              className="rounded-lg bg-emerald-500 hover:bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-slate-950 transition-colors shadow-xs"
            >
              + Submit ARC Request
            </button>
          </div>
        </div>
      </div>

      {/* Dues & Balance Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-emerald-600" />
              <h2 className="text-sm font-bold text-slate-900">HOA Dues & Assessment Status</h2>
            </div>
            <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200/70">
              Paid in Full
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-lg bg-slate-50 p-4 border border-slate-100">
              <span className="text-xs text-slate-500">Current Balance Due</span>
              <div className="text-3xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                ${currentAssessment.balance.toFixed(2)}
              </div>
              <span className="text-xs text-emerald-600 mt-1 block">
                Next billing: October 1, 2026 ($285.00)
              </span>
            </div>

            <div className="rounded-lg bg-slate-50 p-4 border border-slate-100 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-500">Automated Payments</span>
                <div className="text-sm font-semibold text-slate-900 mt-1">
                  {currentAssessment.autoPay ? 'ACH Autopay Active' : 'Manual Billing'}
                </div>
                <span className="text-xs text-slate-400 mt-0.5 block">
                  {currentAssessment.paymentMethod || 'Primary Bank Account'}
                </span>
              </div>
              <button
                onClick={onToggleAutoPay}
                className="mt-3 text-xs text-emerald-700 hover:text-emerald-800 font-medium text-left"
              >
                {currentAssessment.autoPay ? 'Manage auto-pay settings →' : 'Enroll in auto-pay →'}
              </button>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              Last payment cleared on {currentAssessment.lastPaymentDate || 'Sept 27, 2026'}
            </span>
            <button
              onClick={onPayDues}
              className="rounded-lg bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 text-xs font-semibold transition-colors"
            >
              Make One-Time Payment
            </button>
          </div>
        </div>

        {/* Quick Resident Overview */}
        <div className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs space-y-3 text-xs">
          <h3 className="font-bold text-slate-900 border-b border-slate-100 pb-2">
            My Registered Details
          </h3>
          <div className="space-y-2 text-slate-600">
            <div className="flex justify-between">
              <span>Lot:</span>
              <span className="font-semibold text-slate-900">Lot 108</span>
            </div>
            <div className="flex justify-between">
              <span>Permitted Vehicle:</span>
              <span className="font-semibold text-slate-900">Audi Q7 (TX-KRP-55)</span>
            </div>
            <div className="flex justify-between">
              <span>Registered Pet:</span>
              <span className="font-semibold text-slate-900">Cosmo (Russian Blue)</span>
            </div>
            <div className="flex justify-between">
              <span>Clubhouse Access:</span>
              <span className="text-emerald-700 font-semibold">Fob #4092 Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* My Architectural Requests & Violations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ARC Requests */}
        <div className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-sm font-bold text-slate-900">My ARC Applications</h3>
            <button
              onClick={onSubmitArc}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-medium"
            >
              + New Request
            </button>
          </div>
          {myArcRequests.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">
              No recent architectural modification requests on file.
            </p>
          ) : (
            myArcRequests.map((a) => (
              <div key={a.id} className="p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs space-y-1">
                <div className="flex justify-between font-semibold text-slate-800">
                  <span>{a.projectType}</span>
                  <span className="text-emerald-700">{a.status}</span>
                </div>
                <p className="text-slate-600">{a.description}</p>
                <span className="text-[11px] text-slate-400 block pt-1">
                  Submitted {a.submittedDate} · Est. ${a.estimatedCost.toLocaleString()}
                </span>
              </div>
            ))
          )}
        </div>

        {/* Violations / Compliance */}
        <div className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-sm font-bold text-slate-900">Compliance & CC&R Notices</h3>
            <span className="text-xs text-emerald-700 font-medium">0 Open Issues</span>
          </div>
          {myViolations.length === 0 ? (
            <div className="text-xs text-slate-500 py-4 text-center space-y-1">
              <CheckCircle className="h-6 w-6 text-emerald-600 mx-auto" />
              <p className="font-semibold text-slate-800">Your lot is 100% compliant</p>
              <p className="text-slate-400">No active notices or warnings.</p>
            </div>
          ) : (
            myViolations.map((v) => (
              <div key={v.id} className="p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs space-y-1">
                <div className="flex justify-between font-semibold text-slate-800">
                  <span>{v.category}</span>
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {v.stage}
                  </span>
                </div>
                <p className="text-slate-600">{v.description}</p>
                <span className="text-[11px] text-slate-400 block pt-1">
                  Reported {v.dateReported} · {v.stage === 'Resolved' ? 'Resolved on ' + v.resolvedDate : 'Cure by ' + v.cureDeadline}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
