import React, { useState } from 'react';
import { Announcement, Resident, UserRole } from '../types';
import {
  Send,
  MessageSquare,
  Users,
  Car,
  Dog,
  PlusCircle,
  Search,
  Bell,
  Mail,
  Smartphone,
  Pin,
  CheckCircle2,
} from 'lucide-react';

interface CommunicationsHubProps {
  announcements: Announcement[];
  residents: Resident[];
  activeRole: UserRole;
  onOpenBroadcastModal: () => void;
  onOpenNewResidentModal: () => void;
  onTogglePinAnnouncement: (id: string) => void;
}

export const CommunicationsHub: React.FC<CommunicationsHubProps> = ({
  announcements,
  residents,
  activeRole,
  onOpenBroadcastModal,
  onOpenNewResidentModal,
  onTogglePinAnnouncement,
}) => {
  const [tab, setTab] = useState<'announcements' | 'directory'>('announcements');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredAnnouncements = announcements.filter((a) => {
    return (
      a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.body.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.author.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const filteredResidents = residents.filter((r) => {
    return (
      r.unit.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.vehicles.some((v) => v.plate.toLowerCase().includes(searchQuery.toLowerCase()) || v.model.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Resident Communications & Directory
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Community-wide announcements, emergency SMS alerts, and authorized vehicle/pet records.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {tab === 'announcements' ? (
            activeRole !== 'homeowner' && (
              <button
                onClick={onOpenBroadcastModal}
                className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
              >
                <Send className="h-3.5 w-3.5" />
                <span>+ Broadcast Alert</span>
              </button>
            )
          ) : (
            activeRole !== 'homeowner' && (
              <button
                onClick={onOpenNewResidentModal}
                className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                <span>+ Register Resident</span>
              </button>
            )
          )}
        </div>
      </div>

      {/* Switcher Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setTab('announcements')}
          className={`pb-3 text-sm font-semibold transition-colors relative ${
            tab === 'announcements'
              ? 'text-slate-900 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-slate-900'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <span>Announcements & Alerts ({announcements.length})</span>
        </button>
        <button
          onClick={() => setTab('directory')}
          className={`pb-3 text-sm font-semibold transition-colors relative ml-4 ${
            tab === 'directory'
              ? 'text-slate-900 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-slate-900'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <span>Resident & Parking Directory ({residents.length} Lots)</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={tab === 'announcements' ? 'Search notices...' : 'Search resident name, lot, or license plate...'}
          className="w-full rounded-lg border border-slate-200 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none bg-white"
        />
      </div>

      {/* TAB 1: Announcements */}
      {tab === 'announcements' && (
        <div className="space-y-4">
          {filteredAnnouncements.map((item) => (
            <div
              key={item.id}
              className={`rounded-xl border bg-white p-5 shadow-2xs transition-all space-y-3 ${
                item.pinned ? 'border-emerald-300/80 bg-emerald-50/20' : 'border-slate-200/90'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  {item.pinned && (
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200/60">
                      <Pin className="h-3 w-3" /> Pinned
                    </span>
                  )}
                  <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    {item.category}
                  </span>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs text-slate-500 font-mono">{item.date}</span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Delivery Channels */}
                  <div className="flex items-center gap-1 text-slate-400 text-xs">
                    {item.deliveryChannels.includes('SMS') && (
                      <span title="Sent via SMS blast">
                        <Smartphone className="h-3.5 w-3.5 text-slate-600" />
                      </span>
                    )}
                    {item.deliveryChannels.includes('Email') && (
                      <span title="Sent via Email blast">
                        <Mail className="h-3.5 w-3.5 text-slate-600" />
                      </span>
                    )}
                    <span className="text-[11px] text-slate-500">
                      {item.deliveryChannels.join(' / ')}
                    </span>
                  </div>

                  {activeRole !== 'homeowner' && (
                    <button
                      onClick={() => onTogglePinAnnouncement(item.id)}
                      className="text-xs text-slate-400 hover:text-slate-600 px-2 py-1 rounded hover:bg-slate-100 transition-colors"
                      title="Toggle pin to top"
                    >
                      {item.pinned ? 'Unpin' : 'Pin'}
                    </button>
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900">{item.title}</h3>
                <p className="mt-1.5 text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                  {item.body}
                </p>
              </div>

              <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-100">
                <span>Dispatched by: <strong className="text-slate-600 font-medium">{item.author}</strong></span>
                <span className="flex items-center gap-1 text-emerald-700">
                  <CheckCircle2 className="h-3 w-3" /> Delivered to 184 Lots
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: Resident & Parking Directory */}
      {tab === 'directory' && (
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-200/90 bg-white overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/80 text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Unit & Resident</th>
                    <th className="py-3 px-4 font-semibold">Occupancy</th>
                    <th className="py-3 px-4 font-semibold">Contact Info</th>
                    <th className="py-3 px-4 font-semibold">Registered Vehicles (Plate/Permit)</th>
                    <th className="py-3 px-4 font-semibold">Pets</th>
                    <th className="py-3 px-4 font-semibold">Emergency Contact</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredResidents.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{r.unit}</div>
                        <div className="text-slate-600 font-medium">{r.name}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${
                          r.type === 'Owner-Occupied' ? 'bg-slate-100 text-slate-800' : 'bg-blue-50 text-blue-800'
                        }`}>
                          {r.type}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-900">{r.email}</div>
                        <div className="text-slate-500 font-mono mt-0.5">{r.phone}</div>
                      </td>
                      <td className="py-3 px-4">
                        {r.vehicles.length === 0 ? (
                          <span className="text-slate-400">None registered</span>
                        ) : (
                          <div className="space-y-1">
                            {r.vehicles.map((v, i) => (
                              <div key={i} className="flex items-center gap-1.5 text-[11px]">
                                <Car className="h-3 w-3 text-slate-400 shrink-0" />
                                <span className="font-medium text-slate-800">{v.make} {v.model}</span>
                                <span className="text-slate-300">·</span>
                                <span className="font-mono bg-slate-100 px-1 py-0.2 rounded text-[10px] text-slate-700">{v.plate}</span>
                                <span className="text-slate-400 font-mono text-[10px]">({v.permitNo})</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {r.pets.length === 0 ? (
                          <span className="text-slate-400">No pets</span>
                        ) : (
                          <div className="space-y-1">
                            {r.pets.map((p, i) => (
                              <div key={i} className="flex items-center gap-1.5 text-[11px]">
                                <Dog className="h-3 w-3 text-slate-400 shrink-0" />
                                <span className="text-slate-800 font-medium">{p.name}</span>
                                <span className="text-slate-400">({p.breed})</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-500 text-[11px]">
                        {r.emergencyContact}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
