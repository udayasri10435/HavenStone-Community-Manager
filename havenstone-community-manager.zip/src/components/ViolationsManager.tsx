import React, { useState } from 'react';
import { Violation, ArchitecturalRequest, UserRole } from '../types';
import {
  AlertTriangle,
  CheckCircle,
  FileCheck2,
  Clock,
  PlusCircle,
  Search,
  Filter,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  Calendar,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';

interface ViolationsManagerProps {
  violations: Violation[];
  arcRequests: ArchitecturalRequest[];
  activeRole: UserRole;
  onUpdateViolationStage: (id: string, newStage: Violation['stage'], fineAdjustment?: number) => void;
  onResolveViolation: (id: string) => void;
  onOpenNewViolationModal: () => void;
  onOpenNewArcModal: () => void;
  onVoteArc: (requestId: string, vote: 'Approve' | 'Deny', comment?: string) => void;
}

export const ViolationsManager: React.FC<ViolationsManagerProps> = ({
  violations,
  arcRequests,
  activeRole,
  onUpdateViolationStage,
  onResolveViolation,
  onOpenNewViolationModal,
  onOpenNewArcModal,
  onVoteArc,
}) => {
  const [activeTab, setActiveTab] = useState<'violations' | 'arc'>('violations');
  const [stageFilter, setStageFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Filtered violations
  const filteredViolations = violations.filter((v) => {
    const matchesSearch =
      v.unit.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStage = stageFilter === 'All' || v.stage === stageFilter;
    return matchesSearch && matchesStage;
  });

  // Filtered ARC
  const filteredArc = arcRequests.filter((a) => {
    return (
      a.unit.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.projectType.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const stages: Violation['stage'][] = [
    'Courtesy Notice',
    '1st Formal Warning',
    '2nd Notice / Hearing',
    'Fine Levied',
    'Resolved',
  ];

  const getNextStage = (current: Violation['stage']): Violation['stage'] | null => {
    const idx = stages.indexOf(current);
    if (idx >= 0 && idx < stages.length - 1) {
      return stages[idx + 1];
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            CC&R Compliance & Architectural Review
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Covenant enforcement workflows, hearings, fine schedules, and homeowner ARC approvals.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {activeTab === 'violations' ? (
            activeRole !== 'homeowner' && (
              <button
                onClick={onOpenNewViolationModal}
                className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                <span>+ Log Violation</span>
              </button>
            )
          ) : (
            <button
              onClick={onOpenNewArcModal}
              className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>+ Submit ARC Request</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Switcher Tabs (Violations vs ARC) */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('violations')}
          className={`pb-3 text-sm font-semibold transition-colors relative ${
            activeTab === 'violations'
              ? 'text-slate-900 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-slate-900'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <span>CC&R Violations ({violations.filter((v) => v.stage !== 'Resolved').length} Active)</span>
        </button>
        <button
          onClick={() => setActiveTab('arc')}
          className={`pb-3 text-sm font-semibold transition-colors relative ml-4 ${
            activeTab === 'arc'
              ? 'text-slate-900 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-slate-900'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <span>Architectural Review / ARC ({arcRequests.filter((a) => a.status === 'Under Review').length} Pending)</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between bg-white p-3 rounded-xl border border-slate-200/80">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={activeTab === 'violations' ? 'Search lot, owner, or category...' : 'Search project, owner, lot...'}
            className="w-full rounded-lg border border-slate-200 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none"
          />
        </div>

        {activeTab === 'violations' && (
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-slate-400 mr-1 hidden md:inline">Stage:</span>
            {['All', 'Courtesy Notice', '1st Formal Warning', '2nd Notice / Hearing', 'Fine Levied', 'Resolved'].map((st) => (
              <button
                key={st}
                onClick={() => setStageFilter(st)}
                className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                  stageFilter === st
                    ? 'bg-slate-900 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* TAB CONTENT 1: CC&R Violations */}
      {activeTab === 'violations' && (
        <div className="space-y-4">
          {filteredViolations.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-slate-500">
              No violation records match the selected filter.
            </div>
          ) : (
            filteredViolations.map((item) => {
              const nextStage = getNextStage(item.stage);
              return (
                <div
                  key={item.id}
                  className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs hover:border-slate-300 transition-all space-y-4"
                >
                  {/* Top Line */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-slate-900 text-sm">{item.unit}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-xs text-slate-600">{item.ownerName}</span>
                      <span className="text-slate-300">·</span>
                      <span className="font-mono text-xs text-slate-400">{item.id}</span>
                    </div>

                    {/* Stage Badge & Severity */}
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded font-medium ${
                          item.severity === 'High'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200/70'
                            : item.severity === 'Medium'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200/70'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {item.severity} Priority
                      </span>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded font-semibold ${
                          item.stage === 'Resolved'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/70'
                            : item.stage === 'Fine Levied'
                            ? 'bg-rose-100 text-rose-800'
                            : item.stage === '2nd Notice / Hearing'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-800'
                        }`}
                      >
                        {item.stage}
                      </span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <div className="md:col-span-2 space-y-2">
                      <div>
                        <span className="text-slate-400 font-medium uppercase tracking-wider text-[10px]">
                          Category & Rule Citation
                        </span>
                        <p className="text-sm font-semibold text-slate-900 mt-0.5">{item.category}</p>
                      </div>
                      <p className="text-slate-700 leading-relaxed">{item.description}</p>
                      <div className="rounded-lg bg-slate-50 p-2.5 text-slate-600 border border-slate-100">
                        <span className="font-medium text-slate-800">Inspection Note: </span>
                        {item.evidenceNotes}
                      </div>
                    </div>

                    <div className="space-y-2 bg-slate-50/70 p-3.5 rounded-lg border border-slate-200/60">
                      <div className="flex justify-between text-slate-600">
                        <span>Reported Date:</span>
                        <span className="font-mono text-slate-900">{item.dateReported}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Cure Deadline:</span>
                        <span className="font-mono font-medium text-rose-700">{item.cureDeadline}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Fine Amount:</span>
                        <span className="font-mono font-bold text-slate-900">
                          {item.fineAmount > 0 ? `$${item.fineAmount}` : 'None'}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200/60">
                        <span>Inspector:</span>
                        <span className="truncate max-w-[130px]">{item.inspectedBy}</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Bar */}
                  {activeRole !== 'homeowner' && item.stage !== 'Resolved' && (
                    <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs text-slate-500">
                        <span>Escalation path: Courtesy → 1st Warning → Hearing → Fine</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {nextStage && (
                          <button
                            onClick={() =>
                              onUpdateViolationStage(
                                item.id,
                                nextStage,
                                nextStage === 'Fine Levied' ? 150 : 0
                              )
                            }
                            className="flex items-center gap-1 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                          >
                            <span>Escalate to {nextStage}</span>
                            <ArrowRight className="h-3 w-3" />
                          </button>
                        )}
                        <button
                          onClick={() => onResolveViolation(item.id)}
                          className="flex items-center gap-1 rounded-md bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 text-xs font-medium transition-colors"
                        >
                          <CheckCircle className="h-3.5 w-3.5" />
                          <span>Mark Resolved / Cured</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB CONTENT 2: Architectural Review (ARC) */}
      {activeTab === 'arc' && (
        <div className="space-y-4">
          {filteredArc.map((arc) => (
            <div
              key={arc.id}
              className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs hover:border-slate-300 transition-all space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-slate-900 text-sm">{arc.unit}</span>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs text-slate-600">{arc.ownerName}</span>
                  <span className="text-slate-300">·</span>
                  <span className="font-mono text-xs text-slate-400">{arc.id}</span>
                </div>

                <span
                  className={`text-xs px-2.5 py-0.5 rounded font-semibold ${
                    arc.status === 'Approved'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/70'
                      : arc.status === 'Denied'
                      ? 'bg-rose-50 text-rose-700 border border-rose-200/70'
                      : 'bg-amber-50 text-amber-800 border border-amber-200/70'
                  }`}
                >
                  {arc.status}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="md:col-span-2 space-y-2">
                  <div>
                    <span className="text-slate-400 font-medium uppercase tracking-wider text-[10px]">
                      Project Scope
                    </span>
                    <h4 className="text-sm font-bold text-slate-900">{arc.projectType}</h4>
                  </div>
                  <p className="text-slate-700 leading-relaxed">{arc.description}</p>
                  {arc.reviewNotes && (
                    <div className="rounded-lg bg-blue-50/70 p-2.5 text-blue-900 border border-blue-100">
                      <span className="font-semibold">Committee Notes: </span>
                      {arc.reviewNotes}
                    </div>
                  )}

                  {/* Board Votes Log */}
                  <div className="pt-2">
                    <span className="text-slate-400 font-medium uppercase tracking-wider text-[10px] block mb-1">
                      ARC Member Votes ({arc.boardVotes.length})
                    </span>
                    <div className="space-y-1">
                      {arc.boardVotes.length === 0 ? (
                        <p className="text-slate-400 text-xs italic">No committee votes cast yet.</p>
                      ) : (
                        arc.boardVotes.map((v, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs">
                            <span className={`font-semibold ${v.vote === 'Approve' ? 'text-emerald-700' : 'text-rose-700'}`}>
                              [{v.vote}]
                            </span>
                            <span className="text-slate-800">{v.memberName}</span>
                            {v.comment && <span className="text-slate-500 italic">— "{v.comment}"</span>}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2 bg-slate-50/70 p-3.5 rounded-lg border border-slate-200/60">
                  <div className="flex justify-between text-slate-600">
                    <span>Submitted:</span>
                    <span className="font-mono text-slate-900">{arc.submittedDate}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Est. Budget:</span>
                    <span className="font-mono font-medium text-slate-900">
                      ${arc.estimatedCost.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Licensed Contractor:</span>
                    <span className="text-slate-900 truncate max-w-[130px]">{arc.contractorName}</span>
                  </div>
                </div>
              </div>

              {/* Board Voting Actions */}
              {activeRole !== 'homeowner' && arc.status === 'Under Review' && (
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Cast your vote as Architectural Committee Member:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onVoteArc(arc.id, 'Deny', 'Does not meet architectural height guidelines')}
                      className="flex items-center gap-1.5 rounded-md border border-rose-200 bg-rose-50 px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-100 transition-colors"
                    >
                      <ThumbsDown className="h-3.5 w-3.5" />
                      <span>Vote Deny</span>
                    </button>
                    <button
                      onClick={() => onVoteArc(arc.id, 'Approve', 'Meets all CC&R color and setback criteria')}
                      className="flex items-center gap-1.5 rounded-md bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 text-xs font-medium transition-colors"
                    >
                      <ThumbsUp className="h-3.5 w-3.5" />
                      <span>Vote Approve</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
