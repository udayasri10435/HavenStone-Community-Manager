import React, { useState } from 'react';
import { GoverningDocument, UserRole } from '../types';
import {
  FileText,
  Download,
  Search,
  Lock,
  PlusCircle,
  Eye,
  FileCheck,
  ShieldCheck,
} from 'lucide-react';

interface DocumentVaultProps {
  documents: GoverningDocument[];
  activeRole: UserRole;
  onPreviewDocument: (doc: GoverningDocument) => void;
  onUploadDocument: () => void;
}

export const DocumentVault: React.FC<DocumentVaultProps> = ({
  documents,
  activeRole,
  onPreviewDocument,
  onUploadDocument,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  const filteredDocs = documents.filter((doc) => {
    // If homeowner, hide Board Members Only documents
    if (activeRole === 'homeowner' && doc.accessLevel === 'Board Members Only') {
      return false;
    }

    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = categoryFilter === 'All' || doc.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  const categories = [
    'All',
    'CC&Rs & Bylaws',
    'Reserve Study',
    'Financial Audit',
    'Insurance Policy',
    'Architectural Guidelines',
    'Meeting Minutes',
  ];

  const handleDownload = (doc: GoverningDocument) => {
    // Trigger virtual download of a mock text blob with document metadata
    const content = `HAVENSTONE MASTER ASSOCIATION\nOFFICIAL GOVERNING RECORD\n\nTitle: ${doc.title}\nCategory: ${doc.category}\nFile Size: ${doc.fileSize}\nAdopted / Last Updated: ${doc.lastUpdated}\nAccess Authorization: ${doc.accessLevel}\n\nThis record is officially certified by the HavenStone Board of Directors and archived in accordance with Texas Property Code Chapter 209.`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${doc.title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Document Vault & Legal Repository
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Covenants (CC&Rs), Bylaws, certified Reserve Studies, CPA annual audits, and insurance certificates.
          </p>
        </div>

        {activeRole !== 'homeowner' && (
          <button
            onClick={onUploadDocument}
            className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
          >
            <PlusCircle className="h-3.5 w-3.5" />
            <span>+ Upload Document</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between bg-white p-3 rounded-xl border border-slate-200/80">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documents by title or keyword..."
            className="w-full rounded-lg border border-slate-200 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                categoryFilter === cat
                  ? 'bg-slate-900 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredDocs.map((doc) => (
          <div
            key={doc.id}
            className="rounded-xl border border-slate-200/90 bg-white p-4 shadow-2xs hover:border-slate-300 transition-all flex flex-col justify-between space-y-4"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {doc.category}
                </span>
                {doc.accessLevel === 'Board Members Only' ? (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/60">
                    <Lock className="h-3 w-3" /> Board Only
                  </span>
                ) : (
                  <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium border border-emerald-200/60">
                    Public
                  </span>
                )}
              </div>

              <h3 className="text-sm font-bold text-slate-900 leading-snug">{doc.title}</h3>

              <div className="text-xs text-slate-400 flex items-center gap-2 pt-1">
                <span>Updated: {doc.lastUpdated}</span>
                <span>·</span>
                <span className="font-mono">{doc.fileSize}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => onPreviewDocument(doc)}
                className="flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                <Eye className="h-3.5 w-3.5" />
                <span>Quick Preview</span>
              </button>

              <button
                onClick={() => handleDownload(doc)}
                className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <Download className="h-3.5 w-3.5 text-slate-500" />
                <span>Download</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
