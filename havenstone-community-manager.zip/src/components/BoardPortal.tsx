import React, { useState } from 'react';
import { BoardMeeting, BoardResolution, UserRole } from '../types';
import {
  Vote,
  Calendar,
  CheckCircle,
  XCircle,
  MinusCircle,
  PlusCircle,
  Lock,
  Clock,
  MapPin,
  Users,
  FileCheck,
  Building,
} from 'lucide-react';

interface BoardPortalProps {
  meetings: BoardMeeting[];
  resolutions: BoardResolution[];
  activeRole: UserRole;
  onCastVote: (resolutionId: string, vote: 'Aye' | 'Nay' | 'Abstain') => void;
  onOpenNewResolutionModal: () => void;
  onOpenNewMeetingModal: () => void;
}

export const BoardPortal: React.FC<BoardPortalProps> = ({
  meetings,
  resolutions,
  activeRole,
  onCastVote,
  onOpenNewResolutionModal,
  onOpenNewMeetingModal,
}) => {
  const [boardMemberName, setBoardMemberName] = useState('Eleanor Vance (President)');
  const [selectedMeetingTab, setSelectedMeetingTab] = useState<'upcoming' | 'all'>('upcoming');

  const activeResolutions = resolutions.filter((r) => r.status === 'Voting Open');
  const adoptedResolutions = resolutions.filter((r) => r.status === 'Adopted' || r.status === 'Rejected');

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Board Governance & Voting Portal
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Board of directors resolutions, parliamentary motions, meeting agendas, and quorum verification.
          </p>
        </div>

        {activeRole !== 'homeowner' && (
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenNewMeetingModal}
              className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
            >
              <Calendar className="h-3.5 w-3.5 text-slate-500" />
              <span>Schedule Meeting</span>
            </button>
            <button
              onClick={onOpenNewResolutionModal}
              className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>+ Table Resolution</span>
            </button>
          </div>
        )}
      </div>

      {/* Board Member Identity & Quorum Status Banner */}
      <div className="rounded-xl border border-slate-200/90 bg-white p-4 shadow-2xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-blue-700 flex items-center justify-center text-white">
            <Users className="h-5 w-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
              Active Voting Credential
            </span>
            <div className="flex items-center gap-2 mt-0.5">
              <select
                value={boardMemberName}
                onChange={(e) => setBoardMemberName(e.target.value)}
                className="text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded px-2 py-1 focus:outline-none"
              >
                <option value="Eleanor Vance (President)">Eleanor Vance (Board President)</option>
                <option value="Marcus Bennett (Vice President)">Marcus Bennett (Vice President)</option>
                <option value="Carlos Mendoza (Treasurer)">Carlos Mendoza (Treasurer)</option>
                <option value="Brenda Wu (Secretary)">Brenda Wu (Secretary)</option>
                <option value="David Kim (Director at Large)">David Kim (Director at Large)</option>
              </select>
              <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium border border-emerald-200/60">
                Authorized Voter
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs border-t md:border-t-0 pt-2 md:pt-0 border-slate-100">
          <div>
            <span className="text-slate-400 block">Board Seats</span>
            <span className="font-mono font-bold text-slate-800">5 Directors</span>
          </div>
          <div>
            <span className="text-slate-400 block">Quorum Threshold</span>
            <span className="font-mono font-bold text-slate-800">3 of 5 (60%)</span>
          </div>
          <div>
            <span className="text-slate-400 block">Current Status</span>
            <span className="text-emerald-700 font-semibold flex items-center gap-1">
              <CheckCircle className="h-3.5 w-3.5" /> Quorum Active
            </span>
          </div>
        </div>
      </div>

      {/* SECTION 1: Active Motions & Resolutions */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">
            Active Motions & Electronic Voting ({activeResolutions.length})
          </h2>
          <span className="text-xs text-slate-500">Votes legally binding per Bylaws Art. IV</span>
        </div>

        {activeResolutions.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-6 text-center text-slate-500">
            No active motions currently open for voting.
          </div>
        ) : (
          activeResolutions.map((res) => {
            const ayes = res.votes.filter((v) => v.vote === 'Aye').length;
            const nays = res.votes.filter((v) => v.vote === 'Nay').length;
            const abstains = res.votes.filter((v) => v.vote === 'Abstain').length;

            return (
              <div
                key={res.id}
                className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs hover:border-slate-300 transition-all space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60">
                      {res.resolutionNo}
                    </span>
                    <span className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {res.category}
                    </span>
                  </div>

                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200/70">
                    Voting Open (Deadline: Oct 15)
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900">{res.title}</h3>
                  <p className="mt-1.5 text-xs text-slate-700 leading-relaxed">
                    {res.description}
                  </p>
                  {res.budgetImpact && (
                    <div className="mt-2 text-xs font-mono font-medium text-slate-700">
                      Budget Appropriation:{' '}
                      <span className="font-bold text-slate-900">
                        ${res.budgetImpact.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>{' '}
                      (Reserve Account)
                    </div>
                  )}
                </div>

                {/* Vote Tally & Progress */}
                <div className="rounded-lg bg-slate-50 p-3 border border-slate-100 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700">Tally Breakdown:</span>
                    <div className="flex items-center gap-4">
                      <span className="text-emerald-700 font-mono font-bold">{ayes} Aye</span>
                      <span className="text-rose-700 font-mono font-bold">{nays} Nay</span>
                      <span className="text-slate-500 font-mono font-bold">{abstains} Abstain</span>
                    </div>
                  </div>

                  {/* Cast Votes Roll */}
                  <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200/60 flex flex-wrap gap-2">
                    {res.votes.map((v, i) => (
                      <span key={i} className="bg-white px-2 py-0.5 rounded border border-slate-200">
                        <strong>{v.member}</strong>: <span className="font-semibold text-slate-800">{v.vote}</span> ({v.timestamp.slice(11)})
                      </span>
                    ))}
                  </div>
                </div>

                {/* Voting Action Buttons */}
                {activeRole !== 'homeowner' && (
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500">
                      Casting vote as: <strong className="text-slate-800">{boardMemberName}</strong>
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onCastVote(res.id, 'Aye')}
                        className="flex items-center gap-1 rounded-md bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 text-xs font-medium transition-colors"
                      >
                        <CheckCircle className="h-3.5 w-3.5" />
                        <span>Vote Aye</span>
                      </button>
                      <button
                        onClick={() => onCastVote(res.id, 'Nay')}
                        className="flex items-center gap-1 rounded-md bg-rose-700 hover:bg-rose-800 text-white px-3 py-1.5 text-xs font-medium transition-colors"
                      >
                        <XCircle className="h-3.5 w-3.5" />
                        <span>Vote Nay</span>
                      </button>
                      <button
                        onClick={() => onCastVote(res.id, 'Abstain')}
                        className="flex items-center gap-1 rounded-md border border-slate-300 bg-white text-slate-700 px-3 py-1.5 text-xs font-medium hover:bg-slate-50 transition-colors"
                      >
                        <MinusCircle className="h-3.5 w-3.5 text-slate-400" />
                        <span>Abstain</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* SECTION 2: Board Meetings & Agendas */}
      <div className="space-y-4 pt-4">
        <h2 className="text-lg font-bold text-slate-900">
          Scheduled Board Meetings & Agendas
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {meetings.map((m) => (
            <div
              key={m.id}
              className={`rounded-xl border bg-white p-5 shadow-2xs space-y-3 ${
                m.isExecutiveSession ? 'border-amber-300 bg-amber-50/15' : 'border-slate-200/90'
              }`}
            >
              <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5 text-blue-600" />
                  <span className="font-semibold text-slate-900">{m.date}</span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-600">{m.time}</span>
                </div>
                {m.isExecutiveSession && (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                    <Lock className="h-3 w-3" /> Executive Session
                  </span>
                )}
              </div>

              <div>
                <h3 className="text-sm font-bold text-slate-900">{m.title}</h3>
                <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                  <MapPin className="h-3 w-3 text-slate-400" />
                  <span>{m.location}</span>
                </p>
              </div>

              {/* Agenda items list */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Official Agenda
                </span>
                {m.agendaItems.map((item) => (
                  <div key={item.id} className="text-xs text-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="font-mono text-slate-400 text-[11px]">·</span>
                      <span className="truncate">{item.title}</span>
                    </div>
                    <span className="font-mono text-[10px] text-slate-400 shrink-0 ml-2">
                      {item.duration}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-between items-center text-[11px] text-slate-400 border-t border-slate-100">
                <span>Status: <strong className="text-slate-700">{m.status}</strong></span>
                <span className="text-emerald-700 font-medium">Quorum Verified</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
