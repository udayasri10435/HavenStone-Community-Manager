import React from 'react';
import { UserRole } from '../types';
import { ShieldCheck, UserCheck, Home, RefreshCw, Bell, Search } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  activeRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onQuickAction?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  activeRole,
  onRoleChange,
  onQuickAction,
}) => {
  const navItems = [
    { id: 'overview', label: 'Overview' },
    { id: 'dues', label: 'Dues' },
    { id: 'violations', label: 'Violations' },
    { id: 'maintenance', label: 'Maintenance' },
    { id: 'board', label: 'Board' },
    { id: 'communications', label: 'Resident Hub' },
  ];

  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-6 backdrop-blur-sm">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-4">
        <a
          href="#overview"
          onClick={(e) => {
            e.preventDefault();
            onTabChange('overview');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 transition-colors hover:text-emerald-700 whitespace-nowrap"
        >
          HavenStone HOA
        </a>
      </div>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`whitespace-nowrap transition-colors py-1 relative ${
                isActive
                  ? 'text-emerald-700 font-semibold after:absolute after:bottom-[-16px] after:left-0 after:right-0 after:h-[2px] after:bg-emerald-600'
                  : 'hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1-2 primary actions (Role Switcher & Quick Action) */}
      <div className="flex items-center gap-3">
        {/* Role Selector Pill Control */}
        <div className="flex items-center rounded-lg bg-slate-100 p-1 border border-slate-200/80">
          <button
            onClick={() => onRoleChange('property_manager')}
            title="Switch to Property Manager role"
            className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-all whitespace-nowrap ${
              activeRole === 'property_manager'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
            <span className="hidden sm:inline">Manager</span>
          </button>
          <button
            onClick={() => onRoleChange('board_member')}
            title="Switch to Board Member view"
            className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-all whitespace-nowrap ${
              activeRole === 'board_member'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="h-3.5 w-3.5 text-blue-600" />
            <span className="hidden sm:inline">Board</span>
          </button>
          <button
            onClick={() => onRoleChange('homeowner')}
            title="Switch to Homeowner resident portal"
            className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-all whitespace-nowrap ${
              activeRole === 'homeowner'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Home className="h-3.5 w-3.5 text-amber-600" />
            <span className="hidden sm:inline">Homeowner</span>
          </button>
        </div>

        {onQuickAction && (
          <button
            onClick={onQuickAction}
            className="flex items-center gap-2 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-medium text-white transition-colors hover:bg-slate-800 whitespace-nowrap"
          >
            <span>+ New Record</span>
          </button>
        )}
      </div>
    </header>
  );
};
