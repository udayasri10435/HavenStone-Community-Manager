import React, { useState } from 'react';
import { WorkOrder, UserRole } from '../types';
import {
  Wrench,
  AlertCircle,
  Clock,
  CheckCircle2,
  PlusCircle,
  Search,
  Filter,
  Phone,
  DollarSign,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

interface MaintenanceDispatchProps {
  workOrders: WorkOrder[];
  activeRole: UserRole;
  onUpdateStatus: (id: string, newStatus: WorkOrder['status'], actualCost?: number) => void;
  onOpenNewWorkOrderModal: () => void;
}

export const MaintenanceDispatch: React.FC<MaintenanceDispatchProps> = ({
  workOrders,
  activeRole,
  onUpdateStatus,
  onOpenNewWorkOrderModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');

  const filteredOrders = workOrders.filter((wo) => {
    const matchesSearch =
      wo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.vendorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.notes.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'All' || wo.status === statusFilter;
    const matchesPriority = priorityFilter === 'All' || wo.priority === priorityFilter;

    return matchesSearch && matchesStatus && matchesPriority;
  });

  const statuses: WorkOrder['status'][] = [
    'New Request',
    'Dispatched',
    'In Progress',
    'Awaiting Inspection',
    'Completed',
  ];

  const getNextStatus = (current: WorkOrder['status']): WorkOrder['status'] | null => {
    const idx = statuses.indexOf(current);
    if (idx >= 0 && idx < statuses.length - 1) {
      return statuses[idx + 1];
    }
    return null;
  };

  const totalCommitted = workOrders
    .filter((w) => w.status !== 'Completed')
    .reduce((sum, w) => sum + w.estimatedCost, 0);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Maintenance & Vendor Dispatch
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Common property assets, pool facilities, access gates, and contractor work orders.
          </p>
        </div>

        <button
          onClick={onOpenNewWorkOrderModal}
          className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
        >
          <PlusCircle className="h-3.5 w-3.5" />
          <span>+ Create Work Order</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Active Open Orders</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {workOrders.filter((w) => w.status !== 'Completed').length}
            </span>
            <span className="text-xs text-slate-500">
              ({workOrders.filter((w) => w.priority === 'Emergency').length} Emergency)
            </span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">In facility dispatch pipeline</span>
        </div>

        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Estimated Open Repairs</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              ${totalCommitted.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">Allocated to 2026 Operating Maintenance</span>
        </div>

        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Completed This Month</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-700 tabular-nums">
              {workOrders.filter((w) => w.status === 'Completed').length}
            </span>
            <span className="text-xs text-emerald-600 font-medium">100% sign-off</span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">Avg resolution: 3.2 days</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between bg-white p-3 rounded-xl border border-slate-200/80">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search work orders, vendors, locations..."
            className="w-full rounded-lg border border-slate-200 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status Tabs */}
          {['All', 'In Progress', 'Dispatched', 'New Request', 'Completed'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-slate-900 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Work Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-slate-500">
            No maintenance work orders found matching the filter criteria.
          </div>
        ) : (
          filteredOrders.map((order) => {
            const nextStatus = getNextStatus(order.status);
            return (
              <div
                key={order.id}
                className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs hover:border-slate-300 transition-all space-y-4"
              >
                {/* Header Line */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-slate-500">{order.id}</span>
                    <span className="text-slate-300">·</span>
                    <span className="font-semibold text-slate-900 text-sm">{order.location}</span>
                    <span className="text-slate-300">·</span>
                    <span className="text-xs text-slate-600">{order.category}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded font-medium ${
                        order.priority === 'Emergency'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200/80 font-bold'
                          : order.priority === 'High'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200/80'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {order.priority}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded font-semibold ${
                        order.status === 'Completed'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/70'
                          : order.status === 'In Progress'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200/70'
                          : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      {order.status}
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="md:col-span-2 space-y-2">
                    <h3 className="text-sm font-bold text-slate-900">{order.title}</h3>
                    <p className="text-slate-700 leading-relaxed">{order.notes}</p>

                    <div className="flex items-center gap-4 text-slate-500 pt-1">
                      <span>Reported: <span className="font-mono text-slate-800">{order.reportedDate}</span></span>
                      <span>Target: <span className="font-mono text-slate-800">{order.targetCompletion}</span></span>
                    </div>
                  </div>

                  {/* Vendor & Financials Box */}
                  <div className="space-y-2 bg-slate-50/70 p-3.5 rounded-lg border border-slate-200/60">
                    <div className="flex justify-between text-slate-600">
                      <span>Assigned Vendor:</span>
                      <span className="font-semibold text-slate-900 truncate max-w-[130px]">{order.vendorName}</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-600">
                      <span>Vendor Contact:</span>
                      <a href={`tel:${order.vendorPhone}`} className="text-emerald-700 font-mono hover:underline flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        <span>{order.vendorPhone}</span>
                      </a>
                    </div>
                    <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200/60">
                      <span>Estimated Cost:</span>
                      <span className="font-mono font-medium text-slate-900 tabular-nums">
                        ${order.estimatedCost.toFixed(2)}
                      </span>
                    </div>
                    {order.actualCost && (
                      <div className="flex justify-between text-slate-600">
                        <span>Actual Invoiced:</span>
                        <span className="font-mono font-bold text-emerald-700 tabular-nums">
                          ${order.actualCost.toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Status Advancement Actions */}
                {activeRole !== 'homeowner' && order.status !== 'Completed' && (
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500">
                      Lifecycle: New Request → Dispatched → In Progress → Awaiting Inspection → Completed
                    </span>
                    <div className="flex items-center gap-2">
                      {nextStatus && (
                        <button
                          onClick={() => onUpdateStatus(order.id, nextStatus)}
                          className="flex items-center gap-1 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                        >
                          <span>Move to {nextStatus}</span>
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      )}
                      <button
                        onClick={() => onUpdateStatus(order.id, 'Completed', order.estimatedCost)}
                        className="flex items-center gap-1 rounded-md bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 text-xs font-medium transition-colors"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Mark Completed & Invoiced</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
