import React from 'react';
import {
  AssessmentRecord,
  Violation,
  WorkOrder,
  Announcement,
  BoardMeeting,
  UserRole,
} from '../types';
import {
  DollarSign,
  AlertTriangle,
  Wrench,
  Calendar,
  ArrowUpRight,
  Clock,
  Send,
  PlusCircle,
  FileCheck,
} from 'lucide-react';

interface DashboardOverviewProps {
  assessments: AssessmentRecord[];
  violations: Violation[];
  workOrders: WorkOrder[];
  announcements: Announcement[];
  meetings: BoardMeeting[];
  activeRole: UserRole;
  onNavigate: (tab: string) => void;
  onOpenPaymentModal: () => void;
  onOpenViolationModal: () => void;
  onOpenWorkOrderModal: () => void;
  onOpenBroadcastModal: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  assessments,
  violations,
  workOrders,
  announcements,
  meetings,
  activeRole,
  onNavigate,
  onOpenPaymentModal,
  onOpenViolationModal,
  onOpenWorkOrderModal,
  onOpenBroadcastModal,
}) => {
  // Aggregate stats
  const totalBalanceDue = assessments.reduce((sum, a) => sum + a.balance, 0);
  const overdueRecords = assessments.filter(
    (a) => a.status === 'Overdue' || a.status === 'In Collections'
  );
  const overdueSum = overdueRecords.reduce((sum, a) => sum + a.balance, 0);
  const paidCount = assessments.filter((a) => a.status === 'Paid').length;
  const collectionRate = ((paidCount / assessments.length) * 100).toFixed(1);

  const activeViolations = violations.filter((v) => v.stage !== 'Resolved');
  const highSeverityViolations = activeViolations.filter(
    (v) => v.severity === 'High' || v.stage === '2nd Notice / Hearing' || v.stage === 'Fine Levied'
  );

  const activeWorkOrders = workOrders.filter((w) => w.status !== 'Completed');
  const emergencyWorkOrders = activeWorkOrders.filter((w) => w.priority === 'Emergency');

  const nextMeeting = meetings.find((m) => m.status === 'Upcoming') || meetings[0];
  const pinnedAnnouncement = announcements.find((a) => a.pinned) || announcements[0];

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome Bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Community Operations
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Real-time management ledger, physical compliance, and board governance.
          </p>
        </div>

        {/* Quick Operational Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {activeRole === 'homeowner' ? (
            <button
              onClick={onOpenPaymentModal}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-emerald-800 transition-colors"
            >
              <DollarSign className="h-4 w-4" />
              <span>Pay My Dues ($0.00 Balance)</span>
            </button>
          ) : (
            <>
              <button
                onClick={onOpenPaymentModal}
                className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <PlusCircle className="h-3.5 w-3.5 text-slate-500" />
                <span>Record Payment</span>
              </button>
              <button
                onClick={onOpenViolationModal}
                className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <AlertTriangle className="h-3.5 w-3.5 text-rose-500" />
                <span>Log Violation</span>
              </button>
              <button
                onClick={onOpenWorkOrderModal}
                className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <Wrench className="h-3.5 w-3.5 text-slate-500" />
                <span>Dispatch Work Order</span>
              </button>
              <button
                onClick={onOpenBroadcastModal}
                className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
              >
                <Send className="h-3.5 w-3.5" />
                <span>Broadcast Alert</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* 4 Quantitative Metric Cards (Tabular figures, clean unboxed typography) */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Card 1: Collections */}
        <div
          onClick={() => onNavigate('dues')}
          className="cursor-pointer rounded-xl border border-slate-200/90 bg-white p-4 shadow-2xs transition-all hover:border-slate-300 hover:shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Monthly Dues Invoiced</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              $52,440
            </span>
            <span className="text-xs font-medium text-emerald-600">
              {collectionRate}% collected
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>{paidCount} lots paid</span>
            <span className="mx-1.5 text-slate-300">·</span>
            <span>Due on 1st of month</span>
          </div>
        </div>

        {/* Card 2: Delinquency Outstanding */}
        <div
          onClick={() => onNavigate('dues')}
          className="cursor-pointer rounded-xl border border-slate-200/90 bg-white p-4 shadow-2xs transition-all hover:border-slate-300 hover:shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Outstanding Delinquency</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-rose-600 tabular-nums">
              ${overdueSum.toLocaleString()}
            </span>
            <span className="text-xs text-rose-600 font-medium">
              {overdueRecords.length} units
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>1 account in collections</span>
            <span className="mx-1.5 text-slate-300">·</span>
            <span>$150 late fees</span>
          </div>
        </div>

        {/* Card 3: CC&R Compliance */}
        <div
          onClick={() => onNavigate('violations')}
          className="cursor-pointer rounded-xl border border-slate-200/90 bg-white p-4 shadow-2xs transition-all hover:border-slate-300 hover:shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Open CC&R Violations</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {activeViolations.length}
            </span>
            <span className="text-xs font-medium text-amber-600">
              {highSeverityViolations.length} urgent
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>1 hearing scheduled</span>
            <span className="mx-1.5 text-slate-300">·</span>
            <span>$350 in fines</span>
          </div>
        </div>

        {/* Card 4: Active Work Orders */}
        <div
          onClick={() => onNavigate('maintenance')}
          className="cursor-pointer rounded-xl border border-slate-200/90 bg-white p-4 shadow-2xs transition-all hover:border-slate-300 hover:shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Active Maintenance</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {activeWorkOrders.length}
            </span>
            {emergencyWorkOrders.length > 0 && (
              <span className="text-xs font-semibold text-rose-600">
                1 Emergency
              </span>
            )}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>Est. total $5,150</span>
            <span className="mx-1.5 text-slate-300">·</span>
            <span>3 vendors on site</span>
          </div>
        </div>
      </div>

      {/* Main Grid: 2 Columns */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left 2 Columns: Priority Action Queue */}
        <div className="space-y-6 lg:col-span-2">
          {/* Urgent Items Action Board */}
          <div className="rounded-xl border border-slate-200/90 bg-white overflow-hidden shadow-2xs">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <h3 className="text-sm font-semibold text-slate-900">
                  Priority Management Queue
                </h3>
              </div>
              <span className="text-xs text-slate-400">Requires review</span>
            </div>

            <div className="divide-y divide-slate-100">
              {/* Emergency Work Order */}
              {emergencyWorkOrders.map((wo) => (
                <div key={wo.id} className="p-4 flex items-start justify-between gap-4 hover:bg-slate-50/70 transition-colors">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200/80">
                        EMERGENCY MAINTENANCE
                      </span>
                      <span className="text-slate-500 font-mono">{wo.id}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-600 font-medium">{wo.location}</span>
                    </div>
                    <p className="text-sm font-semibold text-slate-900">{wo.title}</p>
                    <p className="text-xs text-slate-500 line-clamp-1">{wo.notes}</p>
                    <div className="text-xs text-slate-500 flex items-center gap-2 pt-0.5">
                      <span>Vendor: {wo.vendorName}</span>
                      <span className="text-slate-300">·</span>
                      <span>Target: {wo.targetCompletion}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => onNavigate('maintenance')}
                    className="shrink-0 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    View Status
                  </button>
                </div>
              ))}

              {/* Overdue Accounts */}
              {overdueRecords.slice(0, 2).map((rec) => (
                <div key={rec.id} className="p-4 flex items-start justify-between gap-4 hover:bg-slate-50/70 transition-colors">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/80">
                        {rec.status.toUpperCase()}
                      </span>
                      <span className="font-medium text-slate-700">{rec.unit}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-500">{rec.ownerName}</span>
                    </div>
                    <p className="text-sm text-slate-800 font-medium">
                      Outstanding balance of{' '}
                      <span className="font-mono font-bold text-rose-600">
                        ${rec.balance.toFixed(2)}
                      </span>{' '}
                      ({rec.feeType})
                    </p>
                    <p className="text-xs text-slate-500">{rec.notes}</p>
                  </div>
                  <button
                    onClick={() => onNavigate('dues')}
                    className="shrink-0 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    Review Ledger
                  </button>
                </div>
              ))}

              {/* High Severity Violation */}
              {highSeverityViolations.slice(0, 1).map((v) => (
                <div key={v.id} className="p-4 flex items-start justify-between gap-4 hover:bg-slate-50/70 transition-colors">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200/80">
                        {v.stage.toUpperCase()}
                      </span>
                      <span className="font-medium text-slate-700">{v.unit}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-500">{v.category}</span>
                    </div>
                    <p className="text-sm text-slate-800 font-medium">{v.description}</p>
                    <p className="text-xs text-slate-500">
                      Cure Deadline: <span className="font-mono">{v.cureDeadline}</span>
                      {v.fineAmount > 0 && ` · Fine Levied: $${v.fineAmount}`}
                    </p>
                  </div>
                  <button
                    onClick={() => onNavigate('violations')}
                    className="shrink-0 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    Manage Notice
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Ledger Snapshot Table */}
          <div className="rounded-xl border border-slate-200/90 bg-white overflow-hidden shadow-2xs">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
              <h3 className="text-sm font-semibold text-slate-900">
                Recent Assessment Billings & Collections
              </h3>
              <button
                onClick={() => onNavigate('dues')}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800"
              >
                View Full Ledger →
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/80 text-slate-500 border-b border-slate-100">
                  <tr>
                    <th className="py-2.5 px-4 font-medium">Unit / Owner</th>
                    <th className="py-2.5 px-4 font-medium">Assessment Type</th>
                    <th className="py-2.5 px-4 font-medium">Due Date</th>
                    <th className="py-2.5 px-4 font-medium text-right">Amount</th>
                    <th className="py-2.5 px-4 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {assessments.slice(0, 5).map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-2.5 px-4">
                        <div className="font-medium text-slate-900">{row.unit}</div>
                        <div className="text-[11px] text-slate-400">{row.ownerName}</div>
                      </td>
                      <td className="py-2.5 px-4 text-slate-600">{row.feeType}</td>
                      <td className="py-2.5 px-4 font-mono text-slate-500">{row.dueDate}</td>
                      <td className="py-2.5 px-4 text-right font-mono font-medium tabular-nums">
                        ${row.amount.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-4">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${
                            row.status === 'Paid'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                              : row.status === 'Pending'
                              ? 'bg-slate-100 text-slate-700'
                              : 'bg-rose-50 text-rose-700 border border-rose-200/60'
                          }`}
                        >
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 1 Column: Board & Community Pulse */}
        <div className="space-y-6">
          {/* Upcoming Board Meeting Card */}
          <div className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-100 pb-3">
              <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                <Calendar className="h-4 w-4 text-blue-600" />
                Next Board Meeting
              </span>
              <span className="font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                Quorum Confirmed
              </span>
            </div>

            <div className="mt-3.5 space-y-2">
              <h4 className="text-sm font-bold text-slate-900">{nextMeeting.title}</h4>
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <Clock className="h-3.5 w-3.5 text-slate-400" />
                <span>{nextMeeting.date} · {nextMeeting.time}</span>
              </div>
              <p className="text-xs text-slate-500">{nextMeeting.location}</p>

              <div className="mt-3 pt-3 border-t border-slate-100">
                <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Key Agenda Items
                </p>
                <div className="space-y-1.5">
                  {nextMeeting.agendaItems.slice(0, 3).map((item) => (
                    <div key={item.id} className="text-xs text-slate-700 flex items-start gap-1.5">
                      <span className="text-slate-400 font-mono">·</span>
                      <span className="line-clamp-1">{item.title}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => onNavigate('board')}
                className="mt-3 w-full rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium py-2 transition-colors"
              >
                Access Board Portal & Vote →
              </button>
            </div>
          </div>

          {/* Pinned Community Notice Card */}
          <div className="rounded-xl border border-slate-200/90 bg-white p-5 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-100 pb-3">
              <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                <FileCheck className="h-4 w-4 text-emerald-600" />
                Community Broadcast
              </span>
              <span className="text-slate-400 text-[11px]">Pinned</span>
            </div>
            <div className="mt-3 space-y-2">
              <h4 className="text-sm font-semibold text-slate-900">
                {pinnedAnnouncement.title}
              </h4>
              <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                {pinnedAnnouncement.body}
              </p>
              <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between">
                <span>By {pinnedAnnouncement.author}</span>
                <span>{pinnedAnnouncement.date}</span>
              </div>
            </div>
          </div>

          {/* Association Key Facts */}
          <div className="rounded-xl border border-slate-200/90 bg-slate-50/50 p-4 text-xs space-y-2.5">
            <h4 className="font-semibold text-slate-800">HavenStone Master Association</h4>
            <div className="flex justify-between text-slate-600">
              <span>Managed Units:</span>
              <span className="font-mono text-slate-900">184 Lots</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Managing Agent:</span>
              <span className="text-slate-900">Sarah Jenkins, CMCA</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Emergency Hotline:</span>
              <span className="font-mono text-slate-900">(512) 555-0199</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Bylaws Revision:</span>
              <span className="text-slate-900">Texas Prop Code § 209</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
