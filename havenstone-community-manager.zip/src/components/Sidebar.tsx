import React from 'react';
import {
  LayoutDashboard,
  CreditCard,
  AlertTriangle,
  Wrench,
  MessageSquare,
  Users,
  Vote,
  FileText,
  Building,
  RotateCcw,
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  activeRole: UserRole;
  onResetData: () => void;
  overdueCount: number;
  openViolationsCount: number;
  activeWorkOrdersCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  activeRole,
  onResetData,
  overdueCount,
  openViolationsCount,
  activeWorkOrdersCount,
}) => {
  const menuItems = [
    {
      id: 'overview',
      label: 'Overview',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'dues',
      label: 'Dues & Ledger',
      icon: CreditCard,
      badge: overdueCount > 0 ? `${overdueCount} due` : null,
      badgeVariant: 'amber',
    },
    {
      id: 'violations',
      label: 'Violations & ARC',
      icon: AlertTriangle,
      badge: openViolationsCount > 0 ? `${openViolationsCount}` : null,
      badgeVariant: 'rose',
    },
    {
      id: 'maintenance',
      label: 'Maintenance',
      icon: Wrench,
      badge: activeWorkOrdersCount > 0 ? `${activeWorkOrdersCount}` : null,
      badgeVariant: 'slate',
    },
    {
      id: 'communications',
      label: 'Communications',
      icon: MessageSquare,
      badge: null,
    },
    {
      id: 'directory',
      label: 'Resident Directory',
      icon: Users,
      badge: null,
    },
    {
      id: 'board',
      label: 'Board Portal',
      icon: Vote,
      badge: null,
    },
    {
      id: 'documents',
      label: 'Document Vault',
      icon: FileText,
      badge: null,
    },
  ];

  return (
    <aside className="w-64 shrink-0 border-r border-slate-200 bg-white flex flex-col justify-between h-[calc(100vh-4rem)] sticky top-16 select-none">
      {/* Top Profile Summary */}
      <div className="p-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-emerald-800 flex items-center justify-center text-white font-semibold text-sm shadow-xs">
            <Building className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-sm font-semibold text-slate-900 truncate">
              HavenStone Community
            </h2>
            <p className="text-xs text-slate-500 truncate">
              184 Homes · Austin, TX
            </p>
          </div>
        </div>

        {/* Active Role indicator bar */}
        <div className="mt-3 rounded-md bg-slate-50 px-2.5 py-1.5 text-xs text-slate-600 border border-slate-200/70 flex items-center justify-between">
          <span className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Viewing as</span>
          <span className="font-semibold text-slate-800 capitalize">
            {activeRole === 'property_manager'
              ? 'Property Manager'
              : activeRole === 'board_member'
              ? 'Board President'
              : 'Resident (Lot 108)'}
          </span>
        </div>
      </div>

      {/* Nav Menu */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    isActive ? 'text-emerald-400' : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`text-[10px] tabular-nums font-semibold px-1.5 py-0.5 rounded ${
                    isActive
                      ? 'bg-slate-800 text-slate-200'
                      : item.badgeVariant === 'rose'
                      ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                      : item.badgeVariant === 'amber'
                      ? 'bg-amber-50 text-amber-700 border border-amber-200/60'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Financial Health Mini Card & Reset */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50">
        <div className="rounded-lg border border-slate-200/80 bg-white p-3 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Operating Fund</span>
            <span className="font-mono font-medium text-slate-900 tabular-nums">$142,650</span>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Capital Reserves</span>
            <span className="font-mono font-medium text-emerald-700 tabular-nums">$486,200</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div className="bg-emerald-600 h-1.5 rounded-full" style={{ width: '88%' }} title="Reserves funded 88%" />
          </div>
          <p className="text-[11px] text-slate-400">88% fully-funded reserve ratio</p>
        </div>

        <button
          onClick={onResetData}
          className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs text-slate-400 hover:text-slate-600 py-1 transition-colors"
          title="Reset local sample changes"
        >
          <RotateCcw className="h-3 w-3" />
          <span>Reset Sample Data</span>
        </button>
      </div>
    </aside>
  );
};
