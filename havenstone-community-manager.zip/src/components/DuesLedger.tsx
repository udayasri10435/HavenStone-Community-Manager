import React, { useState, useMemo } from 'react';
import { AssessmentRecord, UserRole } from '../types';
import {
  CreditCard,
  Search,
  Filter,
  Download,
  PlusCircle,
  AlertCircle,
  CheckCircle2,
  Clock,
  Send,
  SlidersHorizontal,
} from 'lucide-react';

interface DuesLedgerProps {
  assessments: AssessmentRecord[];
  activeRole: UserRole;
  onRecordPayment: (record: AssessmentRecord) => void;
  onApplyLateFee: (recordId: string, feeAmount: number) => void;
  onToggleAutoPay: (recordId: string) => void;
  onSendNotice: (record: AssessmentRecord) => void;
  onOpenNewAssessmentModal: () => void;
}

export const DuesLedger: React.FC<DuesLedgerProps> = ({
  assessments,
  activeRole,
  onRecordPayment,
  onApplyLateFee,
  onToggleAutoPay,
  onSendNotice,
  onOpenNewAssessmentModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Paid' | 'Pending' | 'Overdue' | 'In Collections'>('All');
  const [feeTypeFilter, setFeeTypeFilter] = useState<string>('All');

  // Filtered dataset
  const filteredRecords = useMemo(() => {
    return assessments.filter((rec) => {
      const matchesSearch =
        rec.unit.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.email.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesStatus = statusFilter === 'All' || rec.status === statusFilter;
      const matchesFeeType = feeTypeFilter === 'All' || rec.feeType === feeTypeFilter;

      return matchesSearch && matchesStatus && matchesFeeType;
    });
  }, [assessments, searchQuery, statusFilter, feeTypeFilter]);

  // Aggregate metrics
  const totalBilled = assessments.reduce((sum, a) => sum + a.amount, 0);
  const totalCollected = assessments.filter((a) => a.status === 'Paid').reduce((sum, a) => sum + a.amount, 0);
  const totalOutstanding = assessments.reduce((sum, a) => sum + a.balance, 0);
  const autoPayEnrolled = assessments.filter((a) => a.autoPay).length;
  const autoPayPercent = ((autoPayEnrolled / assessments.length) * 100).toFixed(0);

  // CSV Export handler
  const handleExportCSV = () => {
    const headers = ['ID', 'Unit', 'Owner', 'Email', 'Assessment Type', 'Billed Amount', 'Balance Due', 'Due Date', 'Status', 'AutoPay', 'Last Payment Date', 'Notes'];
    const rows = filteredRecords.map((r) => [
      r.id,
      `"${r.unit}"`,
      `"${r.ownerName}"`,
      r.email,
      `"${r.feeType}"`,
      r.amount.toFixed(2),
      r.balance.toFixed(2),
      r.dueDate,
      r.status,
      r.autoPay ? 'Yes' : 'No',
      r.lastPaymentDate || 'N/A',
      `"${r.notes || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `HavenStone_HOA_Ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Dues & Assessment Ledger
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Unit-level receivables, auto-pay enrollments, and delinquency enforcement.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Download className="h-3.5 w-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          {activeRole !== 'homeowner' && (
            <button
              onClick={onOpenNewAssessmentModal}
              className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>+ Issue Assessment</span>
            </button>
          )}
        </div>
      </div>

      {/* Ledger Stats Bar */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Billed Cycle Total</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-slate-900 tabular-nums">
              ${totalBilled.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">Active monthly billings</span>
        </div>

        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Collected to Date</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-emerald-700 tabular-nums">
              ${totalCollected.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-emerald-600 font-medium">
              {((totalCollected / totalBilled) * 100).toFixed(0)}%
            </span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">Cleared via ACH & Card</span>
        </div>

        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Overdue & In Collections</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-rose-600 tabular-nums">
              ${totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">
            {assessments.filter((a) => a.balance > 0).length} units carrying balance
          </span>
        </div>

        <div className="rounded-xl border border-slate-200/80 bg-white p-4">
          <span className="text-xs text-slate-500 font-medium">Auto-Pay Enrollment</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-slate-900 tabular-nums">
              {autoPayPercent}%
            </span>
            <span className="text-xs text-slate-500">
              ({autoPayEnrolled}/{assessments.length} lots)
            </span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">Zero manual handling</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between bg-white p-3 rounded-xl border border-slate-200/80">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search lot, owner, or email..."
            className="w-full rounded-lg border border-slate-200 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none"
          />
        </div>

        {/* Filter Tabs (Segmented Controls) */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-slate-400 mr-1 hidden md:inline">Status:</span>
          {(['All', 'Paid', 'Pending', 'Overdue', 'In Collections'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-slate-900 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Ledger Table (High-Density, Tabular Figures) */}
      <div className="rounded-xl border border-slate-200/90 bg-white overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Unit & Resident</th>
                <th className="py-3 px-4 font-semibold">Assessment Type</th>
                <th className="py-3 px-4 font-semibold text-right">Billed</th>
                <th className="py-3 px-4 font-semibold text-right">Balance Due</th>
                <th className="py-3 px-4 font-semibold">Due Date</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Auto-Pay</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No assessment records found matching your filters.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{row.unit}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span>{row.ownerName}</span>
                        <span className="text-slate-300">·</span>
                        <span className="text-slate-400">{row.email}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800">{row.feeType}</span>
                      {row.notes && (
                        <div className="text-[11px] text-slate-400 line-clamp-1 max-w-xs">
                          {row.notes}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-medium tabular-nums text-slate-700">
                      ${row.amount.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {row.balance > 0 ? (
                        <span className="font-bold text-rose-600">
                          ${row.balance.toFixed(2)}
                        </span>
                      ) : (
                        <span className="text-slate-400">$0.00</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-500">{row.dueDate}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${
                          row.status === 'Paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                            : row.status === 'Pending'
                            ? 'bg-slate-100 text-slate-700'
                            : row.status === 'Overdue'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200/60'
                            : 'bg-rose-50 text-rose-700 border border-rose-200/60'
                        }`}
                      >
                        {row.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => onToggleAutoPay(row.id)}
                        className={`inline-flex items-center gap-1 text-[11px] font-medium transition-colors ${
                          row.autoPay ? 'text-emerald-700' : 'text-slate-400 hover:text-slate-600'
                        }`}
                        title="Click to toggle auto-pay status"
                      >
                        {row.autoPay ? (
                          <>
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                            <span>Enrolled</span>
                          </>
                        ) : (
                          <span>Disabled</span>
                        )}
                      </button>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onRecordPayment(row)}
                          className="rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                          title="Record payment or credit"
                        >
                          Record Pay
                        </button>
                        {row.balance > 0 && activeRole !== 'homeowner' && (
                          <>
                            <button
                              onClick={() => onApplyLateFee(row.id, 50)}
                              className="rounded-md border border-amber-200 bg-amber-50 px-2 py-1 text-[11px] font-medium text-amber-800 hover:bg-amber-100 transition-colors"
                              title="Apply $50 late assessment penalty"
                            >
                              +$50 Fee
                            </button>
                            <button
                              onClick={() => onSendNotice(row)}
                              className="rounded-md border border-slate-200 bg-white p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
                              title="Send late payment demand notice"
                            >
                              <Send className="h-3.5 w-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
