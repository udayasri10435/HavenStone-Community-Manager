import React, { useState } from 'react';
import {
  AssessmentRecord,
  Violation,
  ArchitecturalRequest,
  WorkOrder,
  Announcement,
  Resident,
  BoardResolution,
  GoverningDocument,
} from '../types';
import { X, Check, DollarSign, AlertTriangle, Wrench, Send, Plus, Lock, FileText, Download } from 'lucide-react';

/* ---------------- Payment Modal ---------------- */
interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  record?: AssessmentRecord | null;
  onSubmit: (data: { recordId: string; amount: number; method: string; reference: string }) => void;
  assessments: AssessmentRecord[];
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  record,
  onSubmit,
  assessments,
}) => {
  if (!isOpen) return null;

  const [selectedId, setSelectedId] = useState(record?.id || assessments[0]?.id || '');
  const currentRec = assessments.find((a) => a.id === selectedId) || record || assessments[0];
  const [amount, setAmount] = useState<string>(
    currentRec?.balance && currentRec.balance > 0
      ? currentRec.balance.toString()
      : currentRec?.amount.toString() || '285'
  );
  const [method, setMethod] = useState('ACH Electronic Transfer');
  const [reference, setReference] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentRec) return;
    onSubmit({
      recordId: currentRec.id,
      amount: parseFloat(amount) || 0,
      method,
      reference: reference || 'TXN-' + Math.floor(100000 + Math.random() * 900000),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">Record HOA Payment</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Select Lot / Account</label>
            <select
              value={selectedId}
              onChange={(e) => {
                setSelectedId(e.target.value);
                const rec = assessments.find((a) => a.id === e.target.value);
                if (rec) setAmount(rec.balance > 0 ? rec.balance.toString() : rec.amount.toString());
              }}
              className="w-full rounded-lg border border-slate-300 p-2 text-xs text-slate-900 focus:outline-none"
            >
              {assessments.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.unit} - {a.ownerName} (Balance: ${a.balance.toFixed(2)})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Payment Amount ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 font-mono text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="ACH Electronic Transfer">ACH Electronic Transfer</option>
                <option value="Credit / Debit Card">Credit / Debit Card</option>
                <option value="Paper Check / Lockbox">Paper Check / Lockbox</option>
                <option value="Bank Wire">Bank Wire</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Check # or Transaction ID</label>
            <input
              type="text"
              placeholder="e.g. Check #4102 or Chase Autopay Ref"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-3.5 py-2 font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-emerald-700 px-4 py-2 font-semibold text-white hover:bg-emerald-800"
            >
              Post Payment to Ledger
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- New CC&R Violation Modal ---------------- */
interface NewViolationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (v: Omit<Violation, 'id'>) => void;
}

export const NewViolationModal: React.FC<NewViolationModalProps> = ({ isOpen, onClose, onSubmit }) => {
  if (!isOpen) return null;

  const [unit, setUnit] = useState('Lot 104 · 1216 HavenStone Way');
  const [ownerName, setOwnerName] = useState('Dr. Gregory Sterling');
  const [category, setCategory] = useState<Violation['category']>('Landscaping & Weeds');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<Violation['severity']>('Medium');
  const [cureDeadline, setCureDeadline] = useState('2026-10-10');
  const [evidenceNotes, setEvidenceNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      unit,
      ownerName,
      category,
      description,
      severity,
      stage: 'Courtesy Notice',
      fineAmount: 0,
      dateReported: new Date().toISOString().slice(0, 10),
      cureDeadline,
      inspectedBy: 'Sarah Jenkins, CMCA (Property Mgr)',
      evidenceNotes: evidenceNotes || 'Logged via field compliance inspection.',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-rose-600" />
            <h3 className="text-base font-bold text-slate-900">Log CC&R Violation Notice</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Unit / Address</label>
              <input
                type="text"
                required
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Owner Name</label>
              <input
                type="text"
                required
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">CC&R Rule Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="Landscaping & Weeds">Landscaping & Weeds</option>
                <option value="Exterior Modification">Exterior Modification (Unapproved)</option>
                <option value="Trash & Recycling Storage">Trash & Recycling Storage</option>
                <option value="Unauthorized Parking">Unauthorized Commercial Parking</option>
                <option value="Noise & Nuisance">Noise & Nuisance</option>
                <option value="Pet Leash Violation">Pet Leash Violation</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Severity & Priority</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="Low">Low Priority (Courtesy)</option>
                <option value="Medium">Medium Priority</option>
                <option value="High">High Priority (Immediate Action)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Detailed Violation Description</label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="State the observed condition and exact violation details..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Cure Deadline</label>
              <input
                type="date"
                required
                value={cureDeadline}
                onChange={(e) => setCureDeadline(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 font-mono text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Inspector Notes</label>
              <input
                type="text"
                placeholder="Field notes / camera evidence log"
                value={evidenceNotes}
                onChange={(e) => setEvidenceNotes(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-3.5 py-2 font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-rose-700 px-4 py-2 font-semibold text-white hover:bg-rose-800"
            >
              Issue Courtesy Notice
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- New Work Order Modal ---------------- */
interface NewWorkOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (wo: Omit<WorkOrder, 'id'>) => void;
}

export const NewWorkOrderModal: React.FC<NewWorkOrderModalProps> = ({ isOpen, onClose, onSubmit }) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('Main Pool & Cabana');
  const [category, setCategory] = useState<WorkOrder['category']>('Pool & Amenities');
  const [priority, setPriority] = useState<WorkOrder['priority']>('Medium');
  const [vendorName, setVendorName] = useState('AquaPro Commercial Pool Solutions');
  const [vendorPhone, setVendorPhone] = useState('(512) 555-0192');
  const [estimatedCost, setEstimatedCost] = useState('1200');
  const [targetCompletion, setTargetCompletion] = useState('2026-10-08');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      title,
      location,
      category,
      priority,
      status: 'Dispatched',
      vendorName,
      vendorPhone,
      estimatedCost: parseFloat(estimatedCost) || 0,
      reportedDate: new Date().toISOString().slice(0, 10),
      targetCompletion,
      notes,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Wrench className="h-5 w-5 text-slate-800" />
            <h3 className="text-base font-bold text-slate-900">Dispatch Maintenance Work Order</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Work Order Title</label>
            <input
              type="text"
              required
              placeholder="e.g. North Gate Safety Eye Repair"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Facility / Common Element</label>
              <input
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="Pool & Amenities">Pool & Amenities</option>
                <option value="Security & Access Gates">Security & Access Gates</option>
                <option value="Plumbing & Irrigation">Plumbing & Irrigation</option>
                <option value="Electrical & Lighting">Electrical & Lighting</option>
                <option value="Landscaping">Landscaping</option>
                <option value="Structural & Roofing">Structural & Roofing</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Assigned Contractor</label>
              <input
                type="text"
                required
                value={vendorName}
                onChange={(e) => setVendorName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Contractor Phone</label>
              <input
                type="text"
                required
                value={vendorPhone}
                onChange={(e) => setVendorPhone(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Emergency">Emergency</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Estimated Cost ($)</label>
              <input
                type="number"
                step="10"
                required
                value={estimatedCost}
                onChange={(e) => setEstimatedCost(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 font-mono text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Completion</label>
              <input
                type="date"
                required
                value={targetCompletion}
                onChange={(e) => setTargetCompletion(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 font-mono text-xs focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Scope of Work & Notes</label>
            <textarea
              rows={2}
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Describe repairs required, model numbers, parts..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-3.5 py-2 font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-slate-900 px-4 py-2 font-semibold text-white hover:bg-slate-800"
            >
              Dispatch Work Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- Broadcast Alert Modal ---------------- */
interface BroadcastModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (a: Omit<Announcement, 'id'>) => void;
}

export const BroadcastModal: React.FC<BroadcastModalProps> = ({ isOpen, onClose, onSubmit }) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Announcement['category']>('General');
  const [body, setBody] = useState('');
  const [pinned, setPinned] = useState(false);
  const [channels, setChannels] = useState<('Email' | 'SMS' | 'Resident Portal' | 'Clubhouse Notice')[]>([
    'Email',
    'SMS',
    'Resident Portal',
  ]);

  const toggleChannel = (ch: any) => {
    setChannels((prev) => (prev.includes(ch) ? prev.filter((c) => c !== ch) : [...prev, ch]));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      title,
      category,
      body,
      date: new Date().toISOString().slice(0, 10),
      author: 'Sarah Jenkins (Property Manager)',
      deliveryChannels: channels,
      pinned,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Send className="h-5 w-5 text-blue-600" />
            <h3 className="text-base font-bold text-slate-900">Broadcast Resident Announcement</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Headline Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Street Sweeping & Parking Notice"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="General">General Community News</option>
                <option value="Maintenance Alert">Maintenance & Closure Alert</option>
                <option value="Board Meeting">Board Meeting & Elections</option>
                <option value="Social Event">Community Social Event</option>
                <option value="Emergency Alert">Emergency Alert</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Audience</label>
              <div className="p-2 border border-slate-200 rounded-lg text-slate-700 bg-slate-50">
                All 184 Lots & Residents
              </div>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Delivery Channels</label>
            <div className="flex flex-wrap gap-2 pt-1">
              {(['Email', 'SMS', 'Resident Portal', 'Clubhouse Notice'] as const).map((ch) => (
                <button
                  type="button"
                  key={ch}
                  onClick={() => toggleChannel(ch)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                    channels.includes(ch)
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {ch}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Announcement Body</label>
            <textarea
              rows={4}
              required
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Enter message text sent via email and resident app..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="pinned"
              checked={pinned}
              onChange={(e) => setPinned(e.target.checked)}
              className="rounded border-slate-300"
            />
            <label htmlFor="pinned" className="text-slate-700 font-medium">
              Pin notice to top of community board
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-3.5 py-2 font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-slate-900 px-4 py-2 font-semibold text-white hover:bg-slate-800"
            >
              Send Broadcast Immediately
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- New ARC Request Modal ---------------- */
interface NewArcModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (arc: Omit<ArchitecturalRequest, 'id'>) => void;
}

export const NewArcModal: React.FC<NewArcModalProps> = ({ isOpen, onClose, onSubmit }) => {
  if (!isOpen) return null;

  const [unit, setUnit] = useState('Lot 108 · 1232 HavenStone Way');
  const [ownerName, setOwnerName] = useState('Elena Rostova');
  const [projectType, setProjectType] = useState<ArchitecturalRequest['projectType']>('Solar Panels');
  const [description, setDescription] = useState('');
  const [estimatedCost, setEstimatedCost] = useState('18500');
  const [contractorName, setContractorName] = useState('Freedom Solar Power Texas');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      unit,
      ownerName,
      projectType,
      description,
      estimatedCost: parseFloat(estimatedCost) || 0,
      contractorName,
      submittedDate: new Date().toISOString().slice(0, 10),
      status: 'Under Review',
      boardVotes: [],
      reviewNotes: 'Application submitted with contractor license and survey plat.',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">Submit Architectural (ARC) Application</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Lot / Address</label>
              <input
                type="text"
                required
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Owner Name</label>
              <input
                type="text"
                required
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Project Category</label>
              <select
                value={projectType}
                onChange={(e) => setProjectType(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
              >
                <option value="Solar Panels">Solar Panels (Rooftop)</option>
                <option value="Exterior Repainting">Exterior Repainting</option>
                <option value="Pergola / Patio Extension">Pergola / Patio Extension</option>
                <option value="Fence Replacement">Fence Replacement</option>
                <option value="Roofing Material">Roofing Material</option>
                <option value="Pool Installation">Inground Pool & Spa</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Est. Budget ($)</label>
              <input
                type="number"
                step="100"
                required
                value={estimatedCost}
                onChange={(e) => setEstimatedCost(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 font-mono text-xs focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Licensed Contractor Name</label>
            <input
              type="text"
              required
              value={contractorName}
              onChange={(e) => setContractorName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Project Specifications & Materials</label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe materials, paint color codes, dimensions, easements..."
              className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-3.5 py-2 font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-emerald-700 px-4 py-2 font-semibold text-white hover:bg-emerald-800"
            >
              Submit Application to ARC Committee
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- Document Preview Modal ---------------- */
interface DocumentPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: GoverningDocument | null;
}

export const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({
  isOpen,
  onClose,
  document,
}) => {
  if (!isOpen || !document) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-emerald-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">{document.title}</h3>
              <p className="text-xs text-slate-500">
                {document.category} · {document.fileSize} · Updated {document.lastUpdated}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Mock Legal Document Viewer */}
        <div className="flex-1 overflow-y-auto bg-slate-50 p-6 rounded-xl border border-slate-200 text-xs text-slate-700 font-mono space-y-4">
          <div className="text-center border-b border-slate-200 pb-3">
            <h4 className="font-bold text-sm text-slate-900 uppercase">
              HAVENSTONE MASTER HOMEOWNERS ASSOCIATION, INC.
            </h4>
            <p className="text-[11px] text-slate-500">Travis County, State of Texas</p>
            <p className="text-[11px] text-slate-500">Official Recording Document ID: TX-2024-CCR-99120</p>
          </div>

          <div>
            <p className="font-bold text-slate-900 uppercase">SECTION 1. AUTHORITY & GOVERNANCE</p>
            <p className="mt-1 leading-relaxed">
              Pursuant to Chapter 209 of the Texas Property Code and the Master Declaration of Covenants,
              Conditions, and Restrictions recorded in the Official Public Records, the Board of Directors
              is vested with the power to assess common area dues, maintain reserve funds, approve
              architectural modifications, and issue notices for non-compliant real property conditions.
            </p>
          </div>

          <div>
            <p className="font-bold text-slate-900 uppercase">SECTION 2. COMPLIANCE & ESCALATION</p>
            <p className="mt-1 leading-relaxed">
              All homeowners must maintain dwelling exteriors, roofs, and front landscaping in a clean and
              orderly condition. A Courtesy Warning will be issued with a 14-day cure window prior to hearing
              scheduling or fine levies.
            </p>
          </div>

          <div>
            <p className="font-bold text-slate-900 uppercase">SECTION 3. CERTIFICATION & SIGNATURES</p>
            <p className="mt-1 leading-relaxed">
              Attested and signed by Eleanor Vance, Board President, and Marcus Bennett, Vice President,
              under seal of the Association.
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
};
