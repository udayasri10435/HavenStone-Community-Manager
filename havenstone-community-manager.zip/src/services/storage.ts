import {
  AssessmentRecord,
  Violation,
  ArchitecturalRequest,
  WorkOrder,
  Announcement,
  Resident,
  BoardMeeting,
  BoardResolution,
  GoverningDocument,
} from '../types';
import {
  INITIAL_ASSESSMENTS,
  INITIAL_VIOLATIONS,
  INITIAL_ARC_REQUESTS,
  INITIAL_WORK_ORDERS,
  INITIAL_ANNOUNCEMENTS,
  INITIAL_RESIDENTS,
  INITIAL_BOARD_MEETINGS,
  INITIAL_RESOLUTIONS,
  INITIAL_DOCUMENTS,
} from '../data/initialData';

const STORAGE_KEYS = {
  ASSESSMENTS: 'havenstone_assessments_v1',
  VIOLATIONS: 'havenstone_violations_v1',
  ARC_REQUESTS: 'havenstone_arc_requests_v1',
  WORK_ORDERS: 'havenstone_work_orders_v1',
  ANNOUNCEMENTS: 'havenstone_announcements_v1',
  RESIDENTS: 'havenstone_residents_v1',
  MEETINGS: 'havenstone_meetings_v1',
  RESOLUTIONS: 'havenstone_resolutions_v1',
  DOCUMENTS: 'havenstone_documents_v1',
};

function getFromStorage<T>(key: string, defaultValue: T): T {
  if (typeof window === 'undefined') return defaultValue;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error loading key ${key}:`, err);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error saving key ${key}:`, err);
  }
}

export const StorageService = {
  getAssessments: (): AssessmentRecord[] => getFromStorage(STORAGE_KEYS.ASSESSMENTS, INITIAL_ASSESSMENTS),
  saveAssessments: (data: AssessmentRecord[]) => saveToStorage(STORAGE_KEYS.ASSESSMENTS, data),

  getViolations: (): Violation[] => getFromStorage(STORAGE_KEYS.VIOLATIONS, INITIAL_VIOLATIONS),
  saveViolations: (data: Violation[]) => saveToStorage(STORAGE_KEYS.VIOLATIONS, data),

  getArcRequests: (): ArchitecturalRequest[] => getFromStorage(STORAGE_KEYS.ARC_REQUESTS, INITIAL_ARC_REQUESTS),
  saveArcRequests: (data: ArchitecturalRequest[]) => saveToStorage(STORAGE_KEYS.ARC_REQUESTS, data),

  getWorkOrders: (): WorkOrder[] => getFromStorage(STORAGE_KEYS.WORK_ORDERS, INITIAL_WORK_ORDERS),
  saveWorkOrders: (data: WorkOrder[]) => saveToStorage(STORAGE_KEYS.WORK_ORDERS, data),

  getAnnouncements: (): Announcement[] => getFromStorage(STORAGE_KEYS.ANNOUNCEMENTS, INITIAL_ANNOUNCEMENTS),
  saveAnnouncements: (data: Announcement[]) => saveToStorage(STORAGE_KEYS.ANNOUNCEMENTS, data),

  getResidents: (): Resident[] => getFromStorage(STORAGE_KEYS.RESIDENTS, INITIAL_RESIDENTS),
  saveResidents: (data: Resident[]) => saveToStorage(STORAGE_KEYS.RESIDENTS, data),

  getMeetings: (): BoardMeeting[] => getFromStorage(STORAGE_KEYS.MEETINGS, INITIAL_BOARD_MEETINGS),
  saveMeetings: (data: BoardMeeting[]) => saveToStorage(STORAGE_KEYS.MEETINGS, data),

  getResolutions: (): BoardResolution[] => getFromStorage(STORAGE_KEYS.RESOLUTIONS, INITIAL_RESOLUTIONS),
  saveResolutions: (data: BoardResolution[]) => saveToStorage(STORAGE_KEYS.RESOLUTIONS, data),

  getDocuments: (): GoverningDocument[] => getFromStorage(STORAGE_KEYS.DOCUMENTS, INITIAL_DOCUMENTS),
  saveDocuments: (data: GoverningDocument[]) => saveToStorage(STORAGE_KEYS.DOCUMENTS, data),

  resetAllData: () => {
    Object.values(STORAGE_KEYS).forEach((k) => localStorage.removeItem(k));
    window.location.reload();
  },
};
