export type UserRole = 'property_manager' | 'board_member' | 'homeowner';

export interface AssessmentRecord {
  id: string;
  unit: string; // e.g. "Lot 104 · 1408 Willow Creek"
  ownerName: string;
  email: string;
  feeType: 'Monthly HOA Dues' | 'Special Reserve Assessment' | 'Pool Clubhouse Surcharge' | 'Late Fee Penalty';
  amount: number;
  balance: number;
  dueDate: string;
  status: 'Paid' | 'Pending' | 'Overdue' | 'In Collections';
  autoPay: boolean;
  lastPaymentDate?: string;
  paymentMethod?: string;
  notes?: string;
}

export interface Violation {
  id: string;
  unit: string;
  ownerName: string;
  category: 'Landscaping & Weeds' | 'Exterior Modification' | 'Trash & Recycling Storage' | 'Unauthorized Parking' | 'Noise & Nuisance' | 'Pet Leash Violation';
  description: string;
  severity: 'Low' | 'Medium' | 'High';
  stage: 'Courtesy Notice' | '1st Formal Warning' | '2nd Notice / Hearing' | 'Fine Levied' | 'Resolved';
  fineAmount: number;
  dateReported: string;
  cureDeadline: string;
  resolvedDate?: string;
  inspectedBy: string;
  evidenceNotes: string;
}

export interface ArchitecturalRequest {
  id: string;
  unit: string;
  ownerName: string;
  projectType: 'Solar Panels' | 'Exterior Repainting' | 'Pergola / Patio Extension' | 'Fence Replacement' | 'Roofing Material' | 'Pool Installation';
  description: string;
  estimatedCost: number;
  contractorName: string;
  submittedDate: string;
  status: 'Under Review' | 'Approved' | 'Approved with Conditions' | 'Denied';
  boardVotes: { memberName: string; vote: 'Approve' | 'Deny'; comment?: string }[];
  reviewNotes?: string;
}

export interface WorkOrder {
  id: string;
  title: string;
  location: string;
  category: 'Plumbing & Irrigation' | 'Electrical & Lighting' | 'Landscaping' | 'Security & Access Gates' | 'Structural & Roofing' | 'Pool & Amenities';
  priority: 'Emergency' | 'High' | 'Medium' | 'Low';
  status: 'New Request' | 'Dispatched' | 'In Progress' | 'Awaiting Inspection' | 'Completed';
  vendorName: string;
  vendorPhone: string;
  estimatedCost: number;
  actualCost?: number;
  reportedDate: string;
  targetCompletion: string;
  notes: string;
}

export interface Announcement {
  id: string;
  title: string;
  category: 'General' | 'Maintenance Alert' | 'Board Meeting' | 'Social Event' | 'Emergency Alert';
  body: string;
  date: string;
  author: string;
  deliveryChannels: ('Email' | 'SMS' | 'Resident Portal' | 'Clubhouse Notice')[];
  pinned: boolean;
}

export interface Resident {
  id: string;
  unit: string;
  name: string;
  type: 'Owner-Occupied' | 'Tenant';
  email: string;
  phone: string;
  vehicles: { make: string; model: string; plate: string; permitNo: string }[];
  pets: { type: string; name: string; breed: string }[];
  emergencyContact: string;
}

export interface BoardMeeting {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  isExecutiveSession: boolean;
  agendaItems: { id: string; title: string; presenter: string; duration: string }[];
  status: 'Upcoming' | 'In Session' | 'Adjourned';
  quorumReached: boolean;
}

export interface BoardResolution {
  id: string;
  resolutionNo: string;
  title: string;
  description: string;
  budgetImpact?: number;
  category: 'Contract Approval' | 'Rule Amendment' | 'Budget & Reserves' | 'ARC Policy';
  status: 'Voting Open' | 'Adopted' | 'Rejected' | 'Tabled';
  votes: { member: string; role: string; vote: 'Aye' | 'Nay' | 'Abstain'; timestamp: string }[];
}

export interface GoverningDocument {
  id: string;
  title: string;
  category: 'CC&Rs & Bylaws' | 'Financial Audit' | 'Reserve Study' | 'Meeting Minutes' | 'Insurance Policy' | 'Architectural Guidelines';
  fileSize: string;
  lastUpdated: string;
  downloadable: boolean;
  accessLevel: 'Public Residents' | 'Board Members Only';
}

export interface CommunityStats {
  totalLots: number;
  occupiedHomes: number;
  operatingBalance: number;
  reserveBalance: number;
  delinquencyRate: number; // percentage
  uncollectedDues: number;
  openViolationsCount: number;
  activeWorkOrdersCount: number;
  pendingArcCount: number;
}
